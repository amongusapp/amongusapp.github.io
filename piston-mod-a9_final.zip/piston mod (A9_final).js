Block.defineBlock(228, "ultatorch", [["torch_on", 0]] , 1, false, 0);
Block.setLightLevel(228,14);
Block.setShape(228,7/16,6/16,7/16,9/16,16/16,9/16);
Block.setRedstoneConsumer(215,true);
Block.setRedstoneConsumer(216,true);

 Block.setRedstoneConsumer(226,true);
Block.setRedstoneConsumer(227,true);


//int breakable[] = {86,69,50,65,78,324,427,428,431,330,323,355,37,38,175,39,103,120,81,354,52,171,78,31,32,6,111,126,28,66,27,331,76,72,70,147,118,131,151,143,77,404,356};
function useItem(x,y,z,a,b,c) {
if(a==205) {
if(c==1) {
 if(Level.getTile(x,y+1,z)==0) {
Level.setTile(x,y+1,z,205,2);
}
}
else if (c==0) { if(Level.getTile(x,y-1,z)==0) {
Level.setTile(x,y-1,z,205,1);
}
}
else if(c==2) {
 if(Level.getTile(x,y,z-1)==0) {
Level.setTile(x,y,z-1,204,1);
}
}
else if(c==3) {
 if(Level.getTile(x,y,z+1)==0) {
Level.setTile(x,y,z+1,204,2);
}
}
 else if(c==4) {
 if(Level.getTile(x-1,y,z)==0) {   Level.setTile(x-1,y,z,205,0);
}
}
 else if(c==5) {
if(Level.getTile(x+1,y,z)==0) { Level.setTile(x+1,y,z,204,0);
}
}
if(Level.getGameMode()==0) {Player.addItemInventory(205,-1,2);
}
}
 if(a==206) {
if(c==1) {
if(Level.getTile(x,y+1,z)==0) { Level.setTile(x,y+1,z,206,2);
}
}
else if (c==0) {
if(Level.getTile(x,y-1,z)==0) {Level.setTile(x,y-1,z,206,1);
}
}
else if(c==2) {
if(Level.getTile(x,y,z-1)==0) {Level.setTile(x,y,z-1,206,4);
}
}
else if(c==3) {
if(Level.getTile(x,y,z+1)==0){ Level.setTile(x,y,z+1,206,5);
}
}
 else if(c==4) {
if(Level.getTile(x-1,y,z)==0) {Level.setTile(x-1,y,z,206,0);
}
}
 else if(c==5) {
if(Level.getTile(x+1,y,z)==0) {Level.setTile(x+1,y,z,206,3);
}
}
if(Level.getGameMode()==0) {Player.addItemInventory(206,-1,2);
}
} 
else if(a==212) {
if(c==1) {
 if(Level.getTile(x,y+1,z)==0) {
Level.setTile(x,y+1,z,212,2);
}
}
else if (c==0) { 
if(Level.getTile(x,y-1,z)==0) {
Level.setTile(x,y-1,z,212,1);
}
}
else if(c==2) {
 if(Level.getTile(x,y,z-1)==0) {
Level.setTile(x,y,z-1,212,4);
}
}
else if(c==3) {
 if(Level.getTile(x,y,z+1)==0) {
Level.setTile(x,y,z+1,212,5);
}
}
 else if(c==4) {
 if(Level.getTile(x-1,y,z)==0) {  
 Level.setTile(x-1,y,z,212,0);
}
}
 else if(c==5) {
if(Level.getTile(x+1,y,z)==0) { 
Level.setTile(x+1,y,z,212,3);
}
}
if(Level.getGameMode()==0) {Player.addItemInventory(212,-1);
}
}
else if(a==216){
if(c==1) {
 if(Level.getTile(x,y+1,z)==0) {
Level.setTile(x,y+1,z,216,2);
}
}
else if (c==0) { 
if(Level.getTile(x,y-1,z)==0) {
Level.setTile(x,y-1,z,216,1);
}
}
else if(c==2) {
 if(Level.getTile(x,y,z-1)==0) {
Level.setTile(x,y,z-1,216,4);
}
}
else if(c==3) {
 if(Level.getTile(x,y,z+1)==0) {
Level.setTile(x,y,z+1,216,5);
}
}
 else if(c==4) {
 if(Level.getTile(x-1,y,z)==0) {  
 Level.setTile(x-1,y,z,216,0);
}
}
 else if(c==5) {
if(Level.getTile(x+1,y,z)==0) { 
Level.setTile(x+1,y,z,216,3);
}
}
if(Level.getGameMode()==0) {Player.addItemInventory(216,-1);
}
}
else if(a==217 || a==218 || a==221 || a==222 || a==226) {
var idf=a;
if(c==1) {
 if(Level.getTile(x,y+1,z)==0) {
Level.setTile(x,y+1,z,idf,2);
}
}
else if (c==0) { 
if(Level.getTile(x,y-1,z)==0) {
Level.setTile(x,y-1,z,idf,1);
}
}
else if(c==2) {
 if(Level.getTile(x,y,z-1)==0) {
Level.setTile(x,y,z-1,idf,4);
}
}
else if(c==3) {
 if(Level.getTile(x,y,z+1)==0) {
Level.setTile(x,y,z+1,idf,5);
}
}
 else if(c==4) {
 if(Level.getTile(x-1,y,z)==0) {  
 Level.setTile(x-1,y,z,idf,0);
}
}
 else if(c==5) {
if(Level.getTile(x+1,y,z)==0) { 
Level.setTile(x+1,y,z,idf,3);
}
}
if(Level.getGameMode()==0) {Player.addItemInventory(idf,-1);
}
}
}
//201
Block.defineBlock(201, "arm.piston.x+", [["pistonarm", 0]] , 1, false, 0);
Block.setRedstoneConsumer(201,true);
Block.setRedstoneConsumer(208,true);
Block.setShape(201,-4/16,6/16,6/16,28/16,10/16,10/16,0);
Block.setShape(201,-12/16,6/16,6/16,20/16,10/16,10/16,1);
Block.setShape(201,6/16,6/16,-12/16,10/16,10/16,20/16,2);
Block.setShape(201,6/16,6/16,-4/16,10/16,10/16,28/16,3);
Block.setShape(201,6/16,-4/16,6/16,10/16,28/16,10/16,4);
Block.setShape(201,6/16,-12/16,6/16,10/16,20/16,10/16,5);
Block.setShape(201,0/16,6/16,6/16,22/16,10/16,10/16,6);
Block.setShape(201,6/16,6/16,6/16,28/16,10/16,10/16,7);
Block.setShape(201,-6/16,6/16,6/16,16/16,10/16,10/16,8);
Block.setShape(201,-12/16,6/16,6/16,10/16,10/16,10/16,9);
Block.setShape(201,6/16,6/16,0/16,10/16,10/16,22/16,10);
Block.setShape(201,6/16,6/16,6/16,10/16,10/16,26/16,11);
Block.setShape(201,6/16,6/16,-6/16,10/16,10/16,16/16,12);
Block.setShape(201,6/16,6/16,-12/16,10/16,10/16,10/16,13);
Block.setShape(201,6/16,0/16,6/16,10/16,22/16,10/16,14);
Block.setShape(201,6/16,6/16,6/16,10/16,28/16,10/16,15);




Block.setColor(201,[0xffffff]);
Block.setLightLevel(201,0.0000001);
Block.setLightOpacity(204,1);
Block.setLightOpacity(205,1);

//202
Block.defineBlock(202, "half.doublepiston", [["pistonside", 0], ["pistonside", 0], ["pistonside", 0], ["pistonside", 0] , ["pistonbottom", 0] , ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",7], ["pistonside", 7] , ["pistonside", 7] , ["pistonside",7]] , 33, false, 0);
Block.setShape(202,1-16/16,0,1-16/16,12/16,16/16,1,0);
Block.defineBlock(208, "half.doublepiston.x-", [["pistonside", 3], ["pistonside", 3], ["pistonside", 3], ["pistonside", 3] , ["pistonbottom", 0] , ["pistonbottom", 0],["pistonside", 6], ["pistonside", 6], ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonside", 3] , ["pistonside", 3] , ["pistonside", 7], ["pistonside", 7], ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonside", 0] , ["pistonside", 0] ,["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",6], ["pistonside", 6] , ["pistonside", 6] , ["pistonside",6], ["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",7], ["pistonside", 7] , ["pistonside", 7] , ["pistonside",7] ] , 33, false, 0);
Block.setShape(208,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(208,0,0,4/16,16/16,16/16,1,1);
Block.setShape(208,0,0,0,16/16,16/16,12/16,2);
Block.setShape(208,0,0,0,16/16,12/16,16/16,3);



 Block.setShape(208,0,4/16,0,16/16,16/16,16/16,4);
//203
Block.defineBlock(203, "head.piston", [["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0] , ["piston_top_normal", 0] , ["piston_top_sticky", 0] , ["pistonhead", 1], ["pistonhead", 1], ["piston_top_normal", 0], ["piston_top_sticky", 0] , ["pistonhead", 0] , ["pistonhead", 0],  ["pistonhead", 1], ["pistonhead", 1], ["piston_top_sticky", 0], ["piston_top_normal", 0] , ["pistonhead", 0] , ["pistonhead", 0], ["piston_top_normal", 0], ["piston_top_sticky", 0], ["pistonhead", 1], ["pistonhead", 1] , ["pistonhead", 1] , ["pistonhead", 1], ["piston_top_sticky", 0], ["piston_top_normal", 0], ["pistonhead", 1], ["pistonhead", 1] , ["pistonhead", 1] , ["pistonhead", 1] ] , 5, false, 0);
Block.setLightLevel(203,1);
Block.setLightLevel(204,0.0000000001);
Block.setRedstoneConsumer(202,true);
Block.setShape(203,12/16,0/16,1-16/16,16/16,16/16,16/16,0);
Block.setShape(203,0,0/16,12/16,16/16,16/16,16/16,1);
Block.setShape(203,0,0/16,0/16,16/16,16/16,4/16,2);
Block.setShape(203,0,12/16,0/16,16/16,16/16,16/16,3);
Block.setShape(203,0,0/16,0/16,16/16,4/16,16/16,4);
Block.setRedstoneConsumer(203,true);
 //204
Block.defineBlock(204, "doublepiston.x+", [["pistonside", 2], ["pistonside", 2], ["pistonside", 1], ["pistonside", 2] , ["pistonbottom", 0] , ["piston_top_sticky", 0], ["pistonside", 6], ["pistonside", 6], ["piston_top_sticky", 0], ["pistonbottom", 0] , ["pistonside", 1] , ["pistonside", 2] ,  ["pistonside", 7], ["pistonside", 7], ["pistonbottom", 0], ["piston_top_sticky", 0] , ["pistonside", 2] ,["pistonside",1]] , 33, true, 0);
Block.setRedstoneConsumer(204,true);
//205
Block.defineBlock(207, "head.piston.x-", [["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0] , ["piston_top_sticky", 0] , ["piston_top_normal", 0]] , 33, false, 0);
Block.setLightLevel(207,1);
Block.setShape(207,0,0,0,4/16,1,1);
Block.defineBlock(205, "Double Sticky Piston", [["pistonside", 1], ["pistonside", 1], ["pistonside", 2], ["pistonside", 1] , ["piston_top_sticky", 0] , ["pistonbottom", 0] ,["piston_top_sticky", 0], ["pistonbottom", 0], ["pistonside", 7], ["pistonside", 7] , ["pistonside", 7] , ["pistonside", 7] ,["pistonbottom", 0], ["piston_top_sticky", 0], ["pistonside", 6], ["pistonside", 6] , ["pistonside", 6] , ["pistonside", 6] ] , 33, true, 0);
Block.setLightLevel(205,0.000000001);
Block.setRedstoneConsumer(205,true);
Block.setLightLevel(205,0.0001);

//206pistonsnormal
Block.defineBlock(206, "Double Piston", [["pistonside", 1], ["pistonside", 1], ["pistonside", 2], ["pistonside", 1] , ["piston_top_normal", 0] , ["pistonbottom", 0] ,["piston_top_normal", 0], ["pistonbottom", 0], ["pistonside", 7], ["pistonside", 7] , ["pistonside", 7] , ["pistonside", 7] ,["pistonbottom", 0], ["piston_top_normal", 0], ["pistonside", 6], ["pistonside", 6] , ["pistonside", 6] , ["pistonside", 6] , ["pistonside", 2], ["pistonside", 2], ["pistonside", 1], ["pistonside", 2] , ["pistonbottom", 0] , ["piston_top_normal", 0], ["pistonside", 6], ["pistonside", 6], ["piston_top_normal", 0], ["pistonbottom", 0] , ["pistonside", 1] , ["pistonside", 2] ,  ["pistonside", 7], ["pistonside", 7], ["pistonbottom", 0], ["piston_top_normal", 0] , ["pistonside", 2] ,["pistonside",1] ] , 33, true, 0);
//209
Block.defineBlock(209, "head.piston", [["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0] , ["piston_top_normal", 0] , ["piston_top_normal", 0] , ["pistonhead", 1], ["pistonhead", 1], ["piston_top_normal", 0], ["piston_top_normal", 0] , ["pistonhead", 0] , ["pistonhead", 0],  ["pistonhead", 1], ["pistonhead", 1], ["piston_top_normal", 0], ["piston_top_normal", 0] , ["pistonhead", 0] , ["pistonhead", 0], ["piston_top_normal", 0], ["piston_top_normal", 0], ["pistonhead", 1], ["pistonhead", 1] , ["pistonhead", 1] , ["pistonhead", 1], ["piston_top_normal", 0], ["piston_top_normal", 0], ["pistonhead", 1], ["pistonhead", 1] , ["pistonhead", 1] , ["pistonhead", 1], ["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0], ["pistonhead", 0] , ["piston_top_normal", 0] , ["piston_top_normal", 0] ] , 5, false, 0);
Block.setShape(209,12/16,0/16,1-16/16,16/16,16/16,16/16,0);
Block.setShape(209,0,0/16,12/16,16/16,16/16,16/16,1);
Block.setShape(209,0,0/16,0/16,16/16,16/16,4/16,2);
Block.setShape(209,0,12/16,0/16,16/16,16/16,16/16,3);
Block.setShape(209,0,0/16,0/16,16/16,4/16,16/16,4);
Block.setShape(209,0,0,0,4/16,1,1,5);

 //210
Block.defineBlock(210, "arm.piston.x+", [["pistonarm", 0]] , 1, false, 0);
Block.setLightLevel(209,1);
Block.setLightOpacity(209,2);
Block.setRedstoneConsumer(211,true); 
Block.setShape(210,-4/16,6/16,6/16,28/16,10/16,10/16,0);
Block.setShape(210,-12/16,6/16,6/16,20/16,10/16,10/16,1);
Block.setShape(210,6/16,6/16,-12/16,10/16,10/16,20/16,2);
Block.setShape(210,6/16,6/16,-4/16,10/16,10/16,28/16,3);
Block.setShape(210,6/16,-4/16,6/16,10/16,28/16,10/16,4);
Block.setShape(210,6/16,-12/16,6/16,10/16,20/16,10/16,5);
Block.setShape(210,6/16,-6/16,6/16,10/16,16/16,10/16,6);
Block.setShape(210,6/16,-12/16,6/16,10/16,10/16,10/16,7);
Block.setShape(210,12/16,6/16,6/16,28/16,10/16,10/16,8);
Block.setShape(210,-12/16,6/16,6/16,4/16,10/16,10/16,9);
Block.setShape(210,6/16,6/16,10/16,10/16,10/16,28/16,10);
Block.setShape(210,6/16,6/16,-12/16,10/16,10/16,4/16,11);
Block.setShape(210,6/16,-12/16,6/16,10/16,4/16,10/16,13);
Block.setShape(210,6/16,12/16,6/16,10/16,28/16,10/16,12);

Block.setColor(210,[0xffffff]);
Block.setLightLevel(210,0.0000001);
Block.setLightLevel(206,0.0000001); 
//211
Block.defineBlock(211, "half.doublepiston.x-", [["pistonside", 3], ["pistonside", 3], ["pistonside", 3], ["pistonside", 3] , ["pistonbottom", 0] , ["pistonbottom", 0],["pistonside", 6], ["pistonside", 6], ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonside", 3] , ["pistonside", 3] , ["pistonside", 7], ["pistonside", 7], ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonside", 0] , ["pistonside", 0] ,["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",6], ["pistonside", 6] , ["pistonside", 6] , ["pistonside",6], ["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",7], ["pistonside", 7] , ["pistonside", 7] , ["pistonside",7] ,["pistonside", 0], ["pistonside", 0], ["pistonside", 0], ["pistonside", 0] , ["pistonbottom", 0] , ["pistonbottom", 0] ] , 33, false, 0);
Block.setShape(211,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(211,0,0,4/16,16/16,16/16,1,1);
Block.setShape(211,0,0,0,16/16,16/16,12/16,2);
Block.setShape(211,0,0,0,16/16,12/16,16/16,3);
Block.setShape(211,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(211,1-16/16,0,1-16/16,12/16,16/16,1,5);
//212


Block.setRedstoneConsumer(212,true);
Block.setRedstoneConsumer(211,true);
Block.setRedstoneConsumer(206,true);
Block.defineBlock(212, "Triple Piston", [["gpistonside", 1], ["gpistonside", 1], ["gpistonside", 2], ["gpistonside", 1] , ["piston_top_normal", 0] , ["gpistonbottom", 0] ,["piston_top_normal", 0], ["gpistonbottom", 0], ["gpistonside", 7], ["gpistonside", 7] , ["gpistonside", 7] , ["gpistonside", 7] ,["gpistonbottom", 0], ["piston_top_normal", 0], ["gpistonside", 6], ["gpistonside", 6] , ["gpistonside", 6] , ["gpistonside", 6] , ["gpistonside", 2], ["gpistonside", 2], ["gpistonside", 1], ["gpistonside", 2] , ["gpistonbottom", 0] , ["piston_top_normal", 0], ["gpistonside", 6], ["gpistonside", 6], ["piston_top_normal", 0], ["gpistonbottom", 0] , ["gpistonside", 1] , ["gpistonside", 2] ,  ["gpistonside", 7], ["gpistonside", 7], ["gpistonbottom", 0], ["piston_top_normal", 0] , ["gpistonside", 2] ,["gpistonside",1] ] , 33, true, 0);
//213
Block.defineBlock(213, "half.triplepiston", [["gpistonside", 3], ["gpistonside", 3], ["gpistonside", 3], ["gpistonside", 3] , ["gpistonbottom", 0] , ["gpistonbottom", 0],["gpistonside", 6], ["gpistonside", 6], ["gpistonbottom", 0], ["gpistonbottom", 0] , ["gpistonside", 3] , ["gpistonside", 3] , ["gpistonside", 7], ["gpistonside", 7], ["gpistonbottom", 0], ["gpistonbottom", 0] , ["gpistonside", 0] , ["gpistonside", 0] ,["gpistonbottom", 0] , ["gpistonbottom", 0] , ["gpistonside",6], ["gpistonside", 6] , ["gpistonside", 6] , ["gpistonside",6], ["gpistonbottom", 0] , ["gpistonbottom", 0] , ["gpistonside",7], ["gpistonside", 7] , ["gpistonside", 7] , ["gpistonside",7] ,["gpistonside", 0], ["gpistonside", 0], ["gpistonside", 0], ["gpistonside", 0] , ["gpistonbottom", 0] , ["gpistonbottom", 0] ] , 33, false, 0);
Block.setShape(213,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(213,0,0,4/16,16/16,16/16,1,1);
Block.setShape(213,0,0,0,16/16,16/16,12/16,2);
Block.setShape(213,0,0,0,16/16,12/16,16/16,3);
Block.setShape(213,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(213,1-16/16,0,1-16/16,12/16,16/16,1,5);
 
Block.setLightLevel(213,0.5);
Block.setLightLevel(212,0.5);
Block.setLightLevel(206,0.5);
Block.setLightLevel(205,0.5);
//214
Block.defineBlock(214, "arm.piston.x+", [["pistonarm", 0]] , 1, false, 0);
Block.setShape(214,-4/16,5/16,5/16,12/16,11/16,11/16,0);
Block.setShape(214,4/16,5/16,5/16,20/16,11/16,11/16,1);
Block.setShape(214,5/16,5/16,-4/16,11/16,11/16,12/16,2);
Block.setShape(214,5/16,5/16,4/16,11/16,11/16,20/16,3);
Block.setShape(214,5/16,-4/16,5/16,11/16,12/16,11/16,4);
Block.setShape(214,5/16,4/16,5/16,11/16,20/16,11/16,5);
Block.setShape(214,-4/16,5/16,5/16,16/16,11/16,11/16,6);
Block.setShape(214,0/16,5/16,5/16,20/16,11/16,11/16,7);
Block.setShape(214,5/16,5/16,-4/16,11/16,11/16,16/16,8);
Block.setShape(214,5/16,5/16,0/16,11/16,11/16,20/16,9);
Block.setShape(214,5/16,-4/16,5/16,11/16,16/16,11/16,10);
Block.setShape(214,5/16,0/16,5/16,11/16,20/16,11/16,11);

//215
Block.defineBlock(215, "half.triplepiston", [["gpistonside", 3], ["gpistonside", 3], ["gpistonside", 3], ["gpistonside", 3] , ["gpistonbottom", 0] , ["gpistonbottom", 0],["gpistonside", 6], ["gpistonside", 6], ["gpistonbottom", 0], ["gpistonbottom", 0] , ["gpistonside", 3] , ["gpistonside", 3] , ["gpistonside", 7], ["gpistonside", 7], ["gpistonbottom", 0], ["gpistonbottom", 0] , ["gpistonside", 0] , ["gpistonside", 0] ,["gpistonbottom", 0] , ["gpistonbottom", 0] , ["gpistonside",6], ["gpistonside", 6] , ["gpistonside", 6] , ["gpistonside",6], ["gpistonbottom", 0] , ["gpistonbottom", 0] , ["gpistonside",7], ["gpistonside", 7] , ["gpistonside", 7] , ["gpistonside",7] ,["gpistonside", 0], ["gpistonside", 0], ["gpistonside", 0], ["gpistonside", 0] , ["gpistonbottom", 0] , ["gpistonbottom", 0] ] , 33, false, 0);
Block.setShape(215,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(215,0,0,4/16,16/16,16/16,1,1);
Block.setShape(215,0,0,0,16/16,16/16,12/16,2);
Block.setShape(215,0,0,0,16/16,12/16,16/16,3);
Block.setShape(215,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(215,1-16/16,0,1-16/16,12/16,16/16,1,5);
//216

 
Block.setRedstoneConsumer(212,true);
Block.setRedstoneConsumer(213,true);
 Block.defineBlock(216, "Triple Sticky Piston", [["gpistonside", 1], ["gpistonside", 1], ["gpistonside", 2], ["gpistonside", 1] , ["piston_top_sticky", 0] , ["gpistonbottom", 0] ,["piston_top_sticky", 0], ["gpistonbottom", 0], ["gpistonside", 7], ["gpistonside", 7] , ["gpistonside", 7] , ["gpistonside", 7] ,["gpistonbottom", 0], ["piston_top_sticky", 0], ["gpistonside", 6], ["gpistonside", 6] , ["gpistonside", 6] , ["gpistonside", 6] , ["gpistonside", 2], ["gpistonside", 2], ["gpistonside", 1], ["gpistonside", 2] , ["gpistonbottom", 0] , ["piston_top_sticky", 0], ["gpistonside", 6], ["gpistonside", 6], ["piston_top_sticky", 0], ["gpistonbottom", 0] , ["gpistonside", 1] , ["gpistonside", 2] ,  ["gpistonside", 7], ["gpistonside", 7], ["gpistonbottom", 0], ["piston_top_sticky", 0] , ["gpistonside", 2] ,["gpistonside",1] ] , 33, true, 0);
//217
Block.setRedstoneConsumer(217,true);
Block.defineBlock(217, "Quadruple Piston", [["ypistonside", 1], ["ypistonside", 1], ["ypistonside", 2], ["ypistonside", 1] , ["piston_top_normal", 0] , ["ypistonbottom", 0] ,["piston_top_normal", 0], ["ypistonbottom", 0], ["ypistonside", 7], ["ypistonside", 7] , ["ypistonside", 7] , ["ypistonside", 7] ,["ypistonbottom", 0], ["piston_top_normal", 0], ["ypistonside", 6], ["ypistonside", 6] , ["ypistonside", 6] , ["ypistonside", 6] , ["ypistonside", 2], ["ypistonside", 2], ["ypistonside", 1], ["ypistonside", 2] , ["ypistonbottom", 0] , ["piston_top_normal", 0], ["ypistonside", 6], ["ypistonside", 6], ["piston_top_normal", 0], ["ypistonbottom", 0] , ["ypistonside", 1] , ["ypistonside", 2] ,  ["ypistonside", 7], ["ypistonside", 7], ["ypistonbottom", 0], ["piston_top_normal", 0] , ["ypistonside", 2] ,["ypistonside",1] ] , 33, true, 0);
//219
Block.defineBlock(219, "half.triplepiston", [["ypistonside", 3], ["ypistonside", 3], ["ypistonside", 3], ["ypistonside", 3] , ["ypistonbottom", 0] , ["ypistonbottom", 0],["ypistonside", 6], ["ypistonside", 6], ["ypistonbottom", 0], ["ypistonbottom", 0] , ["ypistonside", 3] , ["ypistonside", 3] , ["ypistonside", 7], ["ypistonside", 7], ["ypistonbottom", 0], ["ypistonbottom", 0] , ["ypistonside", 0] , ["ypistonside", 0] ,["ypistonbottom", 0] , ["ypistonbottom", 0] , ["ypistonside",6], ["ypistonside", 6] , ["ypistonside", 6] , ["ypistonside",6], ["ypistonbottom", 0] , ["ypistonbottom", 0] , ["ypistonside",7], ["ypistonside", 7] , ["ypistonside", 7] , ["ypistonside",7] ,["ypistonside", 0], ["ypistonside", 0], ["ypistonside", 0], ["ypistonside", 0] , ["ypistonbottom", 0] , ["ypistonbottom", 0] ] , 33, false, 0);
Block.setShape(219,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(219,0,0,4/16,16/16,16/16,1,1);
Block.setShape(219,0,0,0,16/16,16/16,12/16,2);
Block.setShape(219,0,0,0,16/16,12/16,16/16,3);
Block.setShape(219,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(219,1-16/16,0,1-16/16,12/16,16/16,1,5);
 
Block.setLightLevel(219,0.5);
Block.setLightLevel(217,0.5);

//220
Block.defineBlock(220, "half.triplepiston", [["ypistonside", 3], ["ypistonside", 3], ["ypistonside", 3], ["ypistonside", 3] , ["ypistonbottom", 0] , ["ypistonbottom", 0],["ypistonside", 6], ["ypistonside", 6], ["ypistonbottom", 0], ["ypistonbottom", 0] , ["ypistonside", 3] , ["ypistonside", 3] , ["ypistonside", 7], ["ypistonside", 7], ["ypistonbottom", 0], ["ypistonbottom", 0] , ["ypistonside", 0] , ["ypistonside", 0] ,["ypistonbottom", 0] , ["ypistonbottom", 0] , ["ypistonside",6], ["ypistonside", 6] , ["ypistonside", 6] , ["ypistonside",6], ["ypistonbottom", 0] , ["ypistonbottom", 0] , ["ypistonside",7], ["ypistonside", 7] , ["ypistonside", 7] , ["ypistonside",7] ,["ypistonside", 0], ["ypistonside", 0], ["ypistonside", 0], ["ypistonside", 0] , ["ypistonbottom", 0] , ["ypistonbottom", 0] ] , 33, false, 0);
Block.setShape(220,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(220,0,0,4/16,16/16,16/16,1,1);
Block.setShape(220,0,0,0,16/16,16/16,12/16,2);
Block.setShape(220,0,0,0,16/16,12/16,16/16,3);
Block.setShape(220,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(220,1-16/16,0,1-16/16,12/16,16/16,1,5);
//218

  Block.defineBlock(218, "Quadruple Sticky Piston", [["ypistonside", 1], ["ypistonside", 1], ["ypistonside", 2], ["ypistonside", 1] , ["piston_top_sticky", 0] , ["ypistonbottom", 0] ,["piston_top_sticky", 0], ["ypistonbottom", 0], ["ypistonside", 7], ["ypistonside", 7] , ["ypistonside", 7] , ["ypistonside", 7] ,["ypistonbottom", 0], ["piston_top_sticky", 0], ["ypistonside", 6], ["ypistonside", 6] , ["ypistonside", 6] , ["ypistonside", 6] , ["ypistonside", 2], ["ypistonside", 2], ["ypistonside", 1], ["ypistonside", 2] , ["ypistonbottom", 0] , ["piston_top_sticky", 0], ["ypistonside", 6], ["ypistonside", 6], ["piston_top_sticky", 0], ["ypistonbottom", 0] , ["ypistonside", 1] , ["ypistonside", 2] ,  ["ypistonside", 7], ["ypistonside", 7], ["ypistonbottom", 0], ["piston_top_sticky", 0] , ["ypistonside", 2] ,["ypistonside",1] ] , 33, true, 0);
Block.setRedstoneConsumer(218,true);
Block.setRedstoneConsumer(219,true);
Block.setRedstoneConsumer(220,true);

//quituple pistons
//221

Block.defineBlock(221, "Quintuple Piston", [["ppistonside", 1], ["ppistonside", 1], ["ppistonside", 2], ["ppistonside", 1] , ["piston_top_normal", 0] , ["ppistonbottom", 0] ,["piston_top_normal", 0], ["ppistonbottom", 0], ["ppistonside", 7], ["ppistonside", 7] , ["ppistonside", 7] , ["ppistonside", 7] ,["ppistonbottom", 0], ["piston_top_normal", 0], ["ppistonside", 6], ["ppistonside", 6] , ["ppistonside", 6] , ["ppistonside", 6] , ["ppistonside", 2], ["ppistonside", 2], ["ppistonside", 1], ["ppistonside", 2] , ["ppistonbottom", 0] , ["piston_top_normal", 0], ["ppistonside", 6], ["ppistonside", 6], ["piston_top_normal", 0], ["ppistonbottom", 0] , ["ppistonside", 1] , ["ppistonside", 2] ,  ["ppistonside", 7], ["ppistonside", 7], ["ppistonbottom", 0], ["piston_top_normal", 0] , ["ppistonside", 2] ,["ppistonside",1] ] , 33, true, 0);
//223
Block.defineBlock(223, "half.quintuplepiston", [["ppistonside", 3], ["ppistonside", 3], ["ppistonside", 3], ["ppistonside", 3] , ["ppistonbottom", 0] , ["ppistonbottom", 0],["ppistonside", 6], ["ppistonside", 6], ["ppistonbottom", 0], ["ppistonbottom", 0] , ["ppistonside", 3] , ["ppistonside", 3] , ["ppistonside", 7], ["ppistonside", 7], ["ppistonbottom", 0], ["ppistonbottom", 0] , ["ppistonside", 0] , ["ppistonside", 0] ,["ppistonbottom", 0] , ["ppistonbottom", 0] , ["ppistonside",6], ["ppistonside", 6] , ["ppistonside", 6] , ["ppistonside",6], ["ppistonbottom", 0] , ["ppistonbottom", 0] , ["ppistonside",7], ["ppistonside", 7] , ["ppistonside", 7] , ["ppistonside",7] ,["ppistonside", 0], ["ppistonside", 0], ["ppistonside", 0], ["ppistonside", 0] , ["ppistonbottom", 0] , ["ppistonbottom", 0] ] , 33, false, 0);
Block.setShape(223,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(223,0,0,4/16,16/16,16/16,1,1);
Block.setShape(223,0,0,0,16/16,16/16,12/16,2);
Block.setShape(223,0,0,0,16/16,12/16,16/16,3);
Block.setShape(223,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(223,1-16/16,0,1-16/16,12/16,16/16,1,5);
 
Block.setLightLevel(221,0.5);
Block.setLightLevel(222,0.5);
Block.setLightLevel(223,0.5);
Block.setLightLevel(224,0.5);

//224
Block.defineBlock(224, "half.quintuplepiston", [["ppistonside", 3], ["ppistonside", 3], ["ppistonside", 3], ["ppistonside", 3] , ["ppistonbottom", 0] , ["ppistonbottom", 0],["ppistonside", 6], ["ppistonside", 6], ["ppistonbottom", 0], ["ppistonbottom", 0] , ["ppistonside", 3] , ["ppistonside", 3] , ["ppistonside", 7], ["ppistonside", 7], ["ppistonbottom", 0], ["ppistonbottom", 0] , ["ppistonside", 0] , ["ppistonside", 0] ,["ppistonbottom", 0] , ["ppistonbottom", 0] , ["ppistonside",6], ["ppistonside", 6] , ["ppistonside", 6] , ["ppistonside",6], ["ppistonbottom", 0] , ["ppistonbottom", 0] , ["ppistonside",7], ["ppistonside", 7] , ["ppistonside", 7] , ["ppistonside",7] ,["ppistonside", 0], ["ppistonside", 0], ["ppistonside", 0], ["ppistonside", 0] , ["ppistonbottom", 0] , ["ppistonbottom", 0] ] , 33, false, 0);
Block.setShape(224,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(224,0,0,4/16,16/16,16/16,1,1);
Block.setShape(224,0,0,0,16/16,16/16,12/16,2);
Block.setShape(224,0,0,0,16/16,12/16,16/16,3);
Block.setShape(224,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(224,1-16/16,0,1-16/16,12/16,16/16,1,5);
//222

Block.setRedstoneConsumer(221,true);
Block.setRedstoneConsumer(224,true);
Block.setRedstoneConsumer(222,true);
Block.setRedstoneConsumer(223,true);
 Block.defineBlock(222, "Quintuple Sticky Piston", [["ppistonside", 1], ["ppistonside", 1], ["ppistonside", 2], ["ppistonside", 1] , ["piston_top_sticky", 0] , ["ppistonbottom", 0] ,["piston_top_sticky", 0], ["ppistonbottom", 0], ["ppistonside", 7], ["ppistonside", 7] , ["ppistonside", 7] , ["ppistonside", 7] ,["ppistonbottom", 0], ["piston_top_sticky", 0], ["ppistonside", 6], ["ppistonside", 6] , ["ppistonside", 6] , ["ppistonside", 6] , ["ppistonside", 2], ["ppistonside", 2], ["ppistonside", 1], ["ppistonside", 2] , ["ppistonbottom", 0] , ["piston_top_sticky", 0], ["ppistonside", 6], ["ppistonside", 6], ["piston_top_sticky", 0], ["ppistonbottom", 0] , ["ppistonside", 1] , ["ppistonside", 2] ,  ["ppistonside", 7], ["ppistonside", 7], ["ppistonbottom", 0], ["piston_top_sticky", 0] , ["ppistonside", 2] ,["ppistonside",1] ] , 33, true, 0);


Item.setCategory(217, ItemCategory.TOOL)
Item.setCategory(218, ItemCategory.TOOL)
 
Item.setCategory(205, ItemCategory.TOOL)
Item.setCategory(206, ItemCategory.TOOL)
Item.setCategory(212, ItemCategory.TOOL)
Item.setCategory(216, ItemCategory.TOOL)

//225
Block.defineBlock(225, "head.piston.super", [["spistonhead", 0], ["spistonhead", 0], ["spistonhead", 0], ["spistonhead", 0] , ["spiston_top_sticky", 0] , ["spiston_top_sticky", 0] , ["spistonhead", 1], ["spistonhead", 1], ["spiston_top_sticky", 0], ["spiston_top_sticky", 0] , ["spistonhead", 0] , ["spistonhead", 0],  ["spistonhead", 1], ["spistonhead", 1], ["spiston_top_sticky", 0], ["spiston_top_sticky", 0] , ["spistonhead", 0] , ["spistonhead", 0], ["spiston_top_sticky", 0], ["spiston_top_sticky", 0], ["spistonhead", 1], ["spistonhead", 1] , ["spistonhead", 1] , ["spistonhead", 1], ["spiston_top_sticky", 0], ["spiston_top_sticky", 0], ["spistonhead", 1], ["spistonhead", 1] , ["spistonhead", 1] , ["spistonhead", 1] ] , 5, false, 0);
Block.setShape(225,12/16,0/16,1-16/16,16/16,16/16,16/16,0);
Block.setShape(225,0,0/16,12/16,16/16,16/16,16/16,1);
Block.setShape(225,0,0/16,0/16,16/16,16/16,4/16,2);
Block.setShape(225,0,12/16,0/16,16/16,16/16,16/16,3);
Block.setShape(225,0,0/16,0/16,16/16,4/16,16/16,4);
Block.setShape(225,0,0,0,4/16,1,1,5);

//226
Block.defineBlock(226, "Double Super Sticky Piston", [["spistonside", 1], ["spistonside", 1], ["spistonside", 2], ["spistonside", 1] , ["spiston_top_sticky", 0] , ["pistonbottom", 0] ,["spiston_top_sticky", 0], ["pistonbottom", 0], ["spistonside", 7], ["spistonside", 7] , ["spistonside", 7] , ["spistonside", 7] ,["pistonbottom", 0], ["spiston_top_sticky", 0], ["spistonside", 6], ["spistonside", 6] , ["spistonside", 6] , ["spistonside", 6] , ["spistonside", 2], ["spistonside", 2], ["spistonside", 1], ["spistonside", 2] , ["pistonbottom", 0] , ["spiston_top_sticky", 0], ["spistonside", 6], ["spistonside", 6], ["spiston_top_sticky", 0], ["pistonbottom", 0] , ["spistonside", 1] , ["spistonside", 2] ,  ["spistonside", 7], ["spistonside", 7], ["pistonbottom", 0], ["spiston_top_sticky", 0] , ["spistonside", 2] ,["spistonside",1] ] , 33, true, 0);

//227
Block.defineBlock(227, "half.n", [["pistonside", 3], ["pistonside", 3], ["pistonside", 3], ["pistonside", 3] , ["pistonbottom", 0] , ["pistonbottom", 0],["pistonside", 6], ["pistonside", 6], ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonside", 3] , ["pistonside", 3] , ["pistonside", 7], ["pistonside", 7], ["pistonbottom", 0], ["pistonbottom", 0] , ["pistonside", 0] , ["pistonside", 0] ,["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",6], ["pistonside", 6] , ["pistonside", 6] , ["pistonside",6], ["pistonbottom", 0] , ["pistonbottom", 0] , ["pistonside",7], ["pistonside", 7] , ["pistonside", 7] , ["pistonside",7] ,["pistonside", 0], ["pistonside", 0], ["pistonside", 0], ["pistonside", 0] , ["pistonbottom", 0] , ["pistonbottom", 0] ] , 33, false, 0);
Block.setShape(227,4/16,0,1-16/16,16/16,16/16,1,0);
Block.setShape(227,0,0,4/16,16/16,16/16,1,1);
Block.setShape(227,0,0,0,16/16,16/16,12/16,2);
Block.setShape(227,0,0,0,16/16,12/16,16/16,3);
Block.setShape(227,0,4/16,0,16/16,16/16,16/16,4);
Block.setShape(227,1-16/16,0,1-16/16,12/16,16/16,1,5);
 
Block.setLightLevel(225,1);
Block.setLightLevel(227,0.5);
Block.setLightLevel(226,0.5);
 
function redstoneUpdateHook(x, y, z, newCurrent, worldLoaded, blockId, blockData) {
var data=blockData;
if(newCurrent>0) {
if(blockId==204 && blockData==0) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax <x+2 ; ax++) {
if(Level.getTile(ax+1,y,z)>0) {
if(Level.getTile(ax+2,y,z)>0) {
if(Level.getTile(ax+3,y,z)>0) {
if(Level.getTile(ax+4,y,z)>0) {
if(Level.getTile(ax+5,y,z)>0) {
if(Level.getTile(ax+6,y,z)>0) {
if(Level.getTile(ax+7,y,z)>0) {
if(Level.getTile(ax+8,y,z)>0) {
if(Level.getTile(ax+9,y,z)>0) {
if(Level.getTile(ax+10,y,z)>0) {
if(Level.getTile(ax+11,y,z)>0) {
if(Level.getTile(ax+12,y,z)>0) {
if(Level.getTile(ax+13,y,z)>0) {
break;
}
Level.setTile(ax+13,y,z,Level.getTile(ax+12,y,z),Level.getData(ax+12,y,z));
}Level.setTile(ax+12,y,z,Level.getTile(ax+11,y,z),Level.getData(ax+11,y,z));
}Level.setTile(ax+11,y,z,Level.getTile(ax+10,y,z),Level.getData(ax+10,y,z));
}Level.setTile(ax+10,y,z,Level.getTile(ax+9,y,z),Level.getData(ax+9,y,z));
}Level.setTile(ax+9,y,z,Level.getTile(ax+8,y,z),Level.getData(ax+8,y,z));
}Level.setTile(ax+8,y,z,Level.getTile(ax+7,y,z),Level.getData(ax+7,y,z));
}Level.setTile(ax+7,y,z,Level.getTile(ax+6,y,z),Level.getData(ax+6,y,z));
}Level.setTile(ax+6,y,z,Level.getTile(ax+5,y,z),Level.getData(ax+5,y,z));
}Level.setTile(ax+5,y,z,Level.getTile(ax+4,y,z),Level.getData(ax+4,y,z));
}Level.setTile(ax+4,y,z,Level.getTile(ax+3,y,z),Level.getData(ax+3,y,z));
}Level.setTile(ax+3,y,z,Level.getTile(ax+2,y,z),Level.getData(ax+2,y,z));
}Level.setTile(ax+2,y,z,Level.getTile(ax+1,y,z),Level.getData(ax+1,y,z));
}Level.setTile(ax+1,y,z,0); }
if(Level.getTile(x+1,y,z)==0) {
Level.setTile(x,y,z,202,0);
Level.setTile(x+1,y,z,201,0);
Level.setTile(x+2,y,z,203,0);}} 
else if(blockId==205&&blockData==0) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax >x-2 ; ax--) {
if(Level.getTile(ax-1,y,z)>0) {
if(Level.getTile(ax-2,y,z)>0) {
if(Level.getTile(ax-3,y,z)>0) {
if(Level.getTile(ax-4,y,z)>0) {
if(Level.getTile(ax-5,y,z)>0) {
if(Level.getTile(ax-6,y,z)>0) {
if(Level.getTile(ax-7,y,z)>0) {
if(Level.getTile(ax-8,y,z)>0) {
if(Level.getTile(ax-9,y,z)>0) {
if(Level.getTile(ax-10,y,z)>0) {
if(Level.getTile(ax-11,y,z)>0) {
if(Level.getTile(ax-12,y,z)>0) {
if(Level.getTile(ax-13,y,z)>0) {
break;
}
Level.setTile(ax-13,y,z,Level.getTile(ax-12,y,z),Level.getData(ax-12,y,z));
}Level.setTile(ax-12,y,z,Level.getTile(ax-11,y,z),Level.getData(ax-11,y,z));
}Level.setTile(ax-11,y,z,Level.getTile(ax-10,y,z),Level.getData(ax-10,y,z));
}Level.setTile(ax-10,y,z,Level.getTile(ax-9,y,z),Level.getData(ax-9,y,z));
}Level.setTile(ax-9,y,z,Level.getTile(ax-8,y,z),Level.getData(ax-8,y,z));
}Level.setTile(ax-8,y,z,Level.getTile(ax-7,y,z),Level.getData(ax-7,y,z));
}Level.setTile(ax-7,y,z,Level.getTile(ax-6,y,z),Level.getData(ax-6,y,z));
}Level.setTile(ax-6,y,z,Level.getTile(ax-5,y,z),Level.getData(ax-5,y,z));
}Level.setTile(ax-5,y,z,Level.getTile(ax-4,y,z),Level.getData(ax-4,y,z));
}Level.setTile(ax-4,y,z,Level.getTile(ax-3,y,z),Level.getData(ax-3,y,z));
}Level.setTile(ax-3,y,z,Level.getTile(ax-2,y,z),Level.getData(ax-2,y,z));
}Level.setTile(ax-2,y,z,Level.getTile(ax-1,y,z),Level.getData(ax-1,y,z));
}Level.setTile(ax-1,y,z,0); }
if(Level.getTile(x-1,y,z)==0) {
Level.setTile(x,y,z,208,0);
Level.setTile(x-1,y,z,201,1);
Level.setTile(x-2,y,z,207,0);}
}
else if(blockId==204 && blockData==1) {

Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az >z-3 ; az--) {
if(Level.getTile(x,y,az-1)>0) {
if(Level.getTile(x,y,az-2)>0) {
if(Level.getTile(x,y,az-3)>0) {
if(Level.getTile(x,y,az-4)>0) {
if(Level.getTile(x,y,az-5)>0) {
if(Level.getTile(x,y,az-6)>0) {
if(Level.getTile(x,y,az-7)>0) {
if(Level.getTile(x,y,az-8)>0) {
if(Level.getTile(x,y,az-9)>0) {
if(Level.getTile(x,y,az-10)>0) {
if(Level.getTile(x,y,az-11)>0) {
if(Level.getTile(x,y,az-12)>0) {
if(Level.getTile(x,y,az-13)>0) {
break;
}
Level.setTile(x,y,az-13,Level.getTile(x,y,az-12),Level.getData(x,y,az-12));
}Level.setTile(x,y,az-12,Level.getTile(x,y,az-11),Level.getData(x,y,az-11));
}Level.setTile(x,y,az-11,Level.getTile(x,y,az-10),Level.getData(x,y,az-10));
}Level.setTile(x,y,az-10,Level.getTile(x,y,az-9),Level.getData(x,y,az-9));
}Level.setTile(x,y,az-9,Level.getTile(x,y,az-8),Level.getData(x,y,az-8));
}Level.setTile(x,y,az-8,Level.getTile(x,y,az-7),Level.getData(x,y,az-7));
}Level.setTile(x,y,az-7,Level.getTile(x,y,az-6),Level.getData(x,y,az-6));
}Level.setTile(x,y,az-6,Level.getTile(x,y,az-5),Level.getData(x,y,az-5));
}Level.setTile(x,y,az-5,Level.getTile(x,y,az-4),Level.getData(x,y,az-4));
}Level.setTile(x,y,az-4,Level.getTile(x,y,az-3),Level.getData(x,y,az-3));
}Level.setTile(x,y,az-3,Level.getTile(x,y,az-2),Level.getData(x,y,az-2));
}Level.setTile(x,y,az-2,Level.getTile(x,y,az-1),Level.getData(x,y,az-1));
}Level.setTile(x,y,az-1,0); }
if(Level.getTile(x,y,z-1)==0) {
Level.setTile(x,y,z,208,1);
Level.setTile(x,y,z-1,201,2);
Level.setTile(x,y,z-2,203,2);}}
 else if(blockId==204 && blockData==2) {

Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az <z+2 ; az++) {
if(Level.getTile(x,y,az+1)>0) {
if(Level.getTile(x,y,az+2)>0) {
if(Level.getTile(x,y,az+3)>0) {
if(Level.getTile(x,y,az+4)>0) {
if(Level.getTile(x,y,az+5)>0) {
if(Level.getTile(x,y,az+6)>0) {
if(Level.getTile(x,y,az+7)>0) {
if(Level.getTile(x,y,az+8)>0) {
if(Level.getTile(x,y,az+9)>0) {
if(Level.getTile(x,y,az+10)>0) {
if(Level.getTile(x,y,az+11)>0) {
if(Level.getTile(x,y,az+12)>0) {
if(Level.getTile(x,y,az+13)>0) {
break;
}
Level.setTile(x,y,az+13,Level.getTile(x,y,az+12),Level.getData(x,y,az+12));
}Level.setTile(x,y,az+12,Level.getTile(x,y,az+11),Level.getData(x,y,az+11));
}Level.setTile(x,y,az+11,Level.getTile(x,y,az+10),Level.getData(x,y,az+10));
}Level.setTile(x,y,az+10,Level.getTile(x,y,az+9),Level.getData(x,y,az+9));
}Level.setTile(x,y,az+9,Level.getTile(x,y,az+8),Level.getData(x,y,az+8));
}Level.setTile(x,y,az+8,Level.getTile(x,y,az+7),Level.getData(x,y,az+7));
}Level.setTile(x,y,az+7,Level.getTile(x,y,az+6),Level.getData(x,y,az+6));
}Level.setTile(x,y,az+6,Level.getTile(x,y,az+5),Level.getData(x,y,az+5));
}Level.setTile(x,y,az+5,Level.getTile(x,y,az+4),Level.getData(x,y,az+4));
}Level.setTile(x,y,az+4,Level.getTile(x,y,az+3),Level.getData(x,y,az+3));
}Level.setTile(x,y,az+3,Level.getTile(x,y,az+2),Level.getData(x,y,az+2));
}Level.setTile(x,y,az+2,Level.getTile(x,y,az+1),Level.getData(x,y,az+1));
}Level.setTile(x,y,az+1,0); }
if(Level.getTile(x,y,z+1)==0) {
Level.setTile(x,y,z+0,208,2);
Level.setTile(x,y,z+1,201,3);
Level.setTile(x,y,z+2,203,1);}
}
else if (blockId==205 && blockData==1) {

Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay >y-3 ; ay++) {
if(Level.getTile(x,ay-1,z)>0) {
if(Level.getTile(x,ay-2,z)>0) {
if(Level.getTile(x,ay-3,z)>0) {
if(Level.getTile(x,ay-4,z)>0) {
if(Level.getTile(x,ay-5,z)>0) {
if(Level.getTile(x,ay-6,z)>0) {
if(Level.getTile(x,ay-7,z)>0) {
if(Level.getTile(x,ay-8,z)>0) {
if(Level.getTile(x,ay-9,z)>0) {
if(Level.getTile(x,ay-10,z)>0) {
if(Level.getTile(x,ay-11,z)>0) {
if(Level.getTile(x,ay-12,z)>0) {
if(Level.getTile(x,ay-13,z)>0) {
break;
}
Level.setTile(x,ay-13,z,Level.getTile(x,ay-12,z),Level.getData(x,ay-13,z));
}Level.setTile(x,ay-12,z,Level.getTile(x,ay-11,z),Level.getData(x,ay-11,z));
}Level.setTile(x,ay-11,z,Level.getTile(x,ay-10,z),Level.getData(x,ay-10,z));
}Level.setTile(x,ay-10,z,Level.getTile(x,ay-9,z),Level.getData(x,ay-9,z));
}Level.setTile(x,ay-9,z,Level.getTile(x,ay-8,z),Level.getData(x,ay-8,z));
}Level.setTile(x,ay-8,z,Level.getTile(x,ay-7,z),Level.getData(x,ay-7,z));
}Level.setTile(x,ay-7,z,Level.getTile(x,ay-6,z),Level.getData(x,ay-6,z));
}Level.setTile(x,ay-6,z,Level.getTile(x,ay-5,z),Level.getData(x,ay-5,z));
}Level.setTile(x,ay-5,z,Level.getTile(x,ay-4,z),Level.getData(x,ay-4,z));
}Level.setTile(x,ay-4,z,Level.getTile(x,ay-3,z),Level.getData(x,ay-3,z));
}Level.setTile(x,ay-3,z,Level.getTile(x,ay-2,z),Level.getData(x,ay-2,z));
}Level.setTile(x,ay-2,z,Level.getTile(x,ay-1,z),Level.getData(x,ay-1,z));
}Level.setTile(x,ay-1,z,0); }
if(Level.getTile(x,y-1,z)==0) {
Level.setTile(x,y,z,208,4);
Level.setTile(x,y-1,z,210,5);
Level.setTile(x,y-2,z,203,4);
//Level.setTile(x,y-1,z,214,5);
}
}
 else if( blockId==205 && blockData==2) {

Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay <y+2 ; ay++) {
if(Level.getTile(x,ay+1,z)>0) {
if(Level.getTile(x,ay+2,z)>0) {
if(Level.getTile(x,ay+3,z)>0) {
if(Level.getTile(x,ay+4,z)>0) {
if(Level.getTile(x,ay+5,z)>0) {
if(Level.getTile(x,ay+6,z)>0) {
if(Level.getTile(x,ay+7,z)>0) {
if(Level.getTile(x,ay+8,z)>0) {
if(Level.getTile(x,ay+9,z)>0) {
if(Level.getTile(x,ay+10,z)>0) {
if(Level.getTile(x,ay+11,z)>0) {
if(Level.getTile(x,ay+12,z)>0) {
if(Level.getTile(x,ay+13,z)>0) {
break;
}
Level.setTile(x,ay+13,z,Level.getTile(x,ay+12,z),Level.getData(x,ay+13,z));
}Level.setTile(x,ay+12,z,Level.getTile(x,ay+11,z),Level.getData(x,ay+11,z));
}Level.setTile(x,ay+11,z,Level.getTile(x,ay+10,z),Level.getData(x,ay+10,z));
}Level.setTile(x,ay+10,z,Level.getTile(x,ay+9,z),Level.getData(x,ay+9,z));
}Level.setTile(x,ay+9,z,Level.getTile(x,ay+8,z),Level.getData(x,ay+8,z));
}Level.setTile(x,ay+8,z,Level.getTile(x,ay+7,z),Level.getData(x,ay+7,z));
}Level.setTile(x,ay+7,z,Level.getTile(x,ay+6,z),Level.getData(x,ay+6,z));
}Level.setTile(x,ay+6,z,Level.getTile(x,ay+5,z),Level.getData(x,ay+5,z));
}Level.setTile(x,ay+5,z,Level.getTile(x,ay+4,z),Level.getData(x,ay+4,z));
}Level.setTile(x,ay+4,z,Level.getTile(x,ay+3,z),Level.getData(x,ay+3,z));
}Level.setTile(x,ay+3,z,Level.getTile(x,ay+2,z),Level.getData(x,ay+2,z));
}Level.setTile(x,ay+2,z,Level.getTile(x,ay+1,z),Level.getData(x,ay+1,z));
}Level.setTile(x,ay+1,z,0); }
if(Level.getTile(x,y+1,z)==0) {
Level.setTile(x,y,z,208,3);
Level.setTile(x,y+1,z,201,4);
Level.setTile(x,y+2,z,203,3);}
}
else if( blockId==206 && blockData==0 ) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax >x-2 ; ax--) {
if(Level.getTile(ax-1,y,z)>0) {
if(Level.getTile(ax-2,y,z)>0) {
if(Level.getTile(ax-3,y,z)>0) {
if(Level.getTile(ax-4,y,z)>0) {
if(Level.getTile(ax-5,y,z)>0) {
if(Level.getTile(ax-6,y,z)>0) {
if(Level.getTile(ax-7,y,z)>0) {
if(Level.getTile(ax-8,y,z)>0) {
if(Level.getTile(ax-9,y,z)>0) {
if(Level.getTile(ax-10,y,z)>0) {
if(Level.getTile(ax-11,y,z)>0) {
if(Level.getTile(ax-12,y,z)>0) {
if(Level.getTile(ax-13,y,z)>0) {
break;
}
Level.setTile(ax-13,y,z,Level.getTile(ax-12,y,z),Level.getData(ax-12,y,z));
}Level.setTile(ax-12,y,z,Level.getTile(ax-11,y,z),Level.getData(ax-11,y,z));
}Level.setTile(ax-11,y,z,Level.getTile(ax-10,y,z),Level.getData(ax-10,y,z));
}Level.setTile(ax-10,y,z,Level.getTile(ax-9,y,z),Level.getData(ax-9,y,z));
}Level.setTile(ax-9,y,z,Level.getTile(ax-8,y,z),Level.getData(ax-8,y,z));
}Level.setTile(ax-8,y,z,Level.getTile(ax-7,y,z),Level.getData(ax-7,y,z));
}Level.setTile(ax-7,y,z,Level.getTile(ax-6,y,z),Level.getData(ax-6,y,z));
}Level.setTile(ax-6,y,z,Level.getTile(ax-5,y,z),Level.getData(ax-5,y,z));
}Level.setTile(ax-5,y,z,Level.getTile(ax-4,y,z),Level.getData(ax-4,y,z));
}Level.setTile(ax-4,y,z,Level.getTile(ax-3,y,z),Level.getData(ax-3,y,z));
}Level.setTile(ax-3,y,z,Level.getTile(ax-2,y,z),Level.getData(ax-2,y,z));
}Level.setTile(ax-2,y,z,Level.getTile(ax-1,y,z),Level.getData(ax-1,y,z));
}Level.setTile(ax-1,y,z,0); }
if(Level.getTile(x-1,y,z)==0) {
Level.setTile(x,y,z,211,0);
Level.setTile(x-1,y,z,210,1);
Level.setTile(x-2,y,z,209,5);}
}
else if(blockId==206 && blockData==3) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax <x+2 ; ax++) {
if(Level.getTile(ax+1,y,z)>0) {
if(Level.getTile(ax+2,y,z)>0) {
if(Level.getTile(ax+3,y,z)>0) {
if(Level.getTile(ax+4,y,z)>0) {
if(Level.getTile(ax+5,y,z)>0) {
if(Level.getTile(ax+6,y,z)>0) {
if(Level.getTile(ax+7,y,z)>0) {
if(Level.getTile(ax+8,y,z)>0) {
if(Level.getTile(ax+9,y,z)>0) {
if(Level.getTile(ax+10,y,z)>0) {
if(Level.getTile(ax+11,y,z)>0) {
if(Level.getTile(ax+12,y,z)>0) {
if(Level.getTile(ax+13,y,z)>0) {
break;
}
Level.setTile(ax+13,y,z,Level.getTile(ax+12,y,z),Level.getData(ax+12,y,z));
}Level.setTile(ax+12,y,z,Level.getTile(ax+11,y,z),Level.getData(ax+11,y,z));
}Level.setTile(ax+11,y,z,Level.getTile(ax+10,y,z),Level.getData(ax+10,y,z));
}Level.setTile(ax+10,y,z,Level.getTile(ax+9,y,z),Level.getData(ax+9,y,z));
}Level.setTile(ax+9,y,z,Level.getTile(ax+8,y,z),Level.getData(ax+8,y,z));
}Level.setTile(ax+8,y,z,Level.getTile(ax+7,y,z),Level.getData(ax+7,y,z));
}Level.setTile(ax+7,y,z,Level.getTile(ax+6,y,z),Level.getData(ax+6,y,z));
}Level.setTile(ax+6,y,z,Level.getTile(ax+5,y,z),Level.getData(ax+5,y,z));
}Level.setTile(ax+5,y,z,Level.getTile(ax+4,y,z),Level.getData(ax+4,y,z));
}Level.setTile(ax+4,y,z,Level.getTile(ax+3,y,z),Level.getData(ax+3,y,z));
}Level.setTile(ax+3,y,z,Level.getTile(ax+2,y,z),Level.getData(ax+2,y,z));
}Level.setTile(ax+2,y,z,Level.getTile(ax+1,y,z),Level.getData(ax+1,y,z));
}Level.setTile(ax+1,y,z,0); }
if(Level.getTile(x+1,y,z)==0) {
Level.setTile(x,y,z,211,5);
Level.setTile(x+1,y,z,210,0);
Level.setTile(x+2,y,z,209,0);}
}
else if(blockId==206 && blockData==1) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay >y-2 ; ay--) {
if(Level.getTile(x,ay-1,z)>0) {
if(Level.getTile(x,ay-2,z)>0) {
if(Level.getTile(x,ay-3,z)>0) {
if(Level.getTile(x,ay-4,z)>0) {
if(Level.getTile(x,ay-5,z)>0) {
if(Level.getTile(x,ay-6,z)>0) {
if(Level.getTile(x,ay-7,z)>0) {
if(Level.getTile(x,ay-8,z)>0) {
if(Level.getTile(x,ay-9,z)>0) {
if(Level.getTile(x,ay-10,z)>0) {
if(Level.getTile(x,ay-11,z)>0) {
if(Level.getTile(x,ay-12,z)>0) {
if(Level.getTile(x,ay-13,z)>0) {
break;
}
Level.setTile(x,ay-13,z,Level.getTile(x,ay-12,z),Level.getData(x,ay-13,z));
}Level.setTile(x,ay-12,z,Level.getTile(x,ay-11,z),Level.getData(x,ay-11,z));
}Level.setTile(x,ay-11,z,Level.getTile(x,ay-10,z),Level.getData(x,ay-10,z));
}Level.setTile(x,ay-10,z,Level.getTile(x,ay-9,z),Level.getData(x,ay-9,z));
}Level.setTile(x,ay-9,z,Level.getTile(x,ay-8,z),Level.getData(x,ay-8,z));
}Level.setTile(x,ay-8,z,Level.getTile(x,ay-7,z),Level.getData(x,ay-7,z));
}Level.setTile(x,ay-7,z,Level.getTile(x,ay-6,z),Level.getData(x,ay-6,z));
}Level.setTile(x,ay-6,z,Level.getTile(x,ay-5,z),Level.getData(x,ay-5,z));
}Level.setTile(x,ay-5,z,Level.getTile(x,ay-4,z),Level.getData(x,ay-4,z));
}Level.setTile(x,ay-4,z,Level.getTile(x,ay-3,z),Level.getData(x,ay-3,z));
}Level.setTile(x,ay-3,z,Level.getTile(x,ay-2,z),Level.getData(x,ay-2,z));
}Level.setTile(x,ay-2,z,Level.getTile(x,ay-1,z),Level.getData(x,ay-1,z));
}Level.setTile(x,ay-1,z,0); }
if(Level.getTile(x,y-1,z)==0) {
Level.setTile(x,y,z,211,4);
Level.setTile(x,y-1,z,210,5);
Level.setTile(x,y-2,z,209,4);
//Level.setTile(x,y-1,z,214,5);
}
}
else if(blockId==206 && blockData==2) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay <y+2 ; ay++) {
if(Level.getTile(x,ay+1,z)>0) {
if(Level.getTile(x,ay+2,z)>0) {
if(Level.getTile(x,ay+3,z)>0) {
if(Level.getTile(x,ay+4,z)>0) {
if(Level.getTile(x,ay+5,z)>0) {
if(Level.getTile(x,ay+6,z)>0) {
if(Level.getTile(x,ay+7,z)>0) {
if(Level.getTile(x,ay+8,z)>0) {
if(Level.getTile(x,ay+9,z)>0) {
if(Level.getTile(x,ay+10,z)>0) {
if(Level.getTile(x,ay+11,z)>0) {
if(Level.getTile(x,ay+12,z)>0) {
if(Level.getTile(x,ay+13,z)>0) {
break;
}
Level.setTile(x,ay+13,z,Level.getTile(x,ay+12,z),Level.getData(x,ay+13,z));
}Level.setTile(x,ay+12,z,Level.getTile(x,ay+11,z),Level.getData(x,ay+11,z));
}Level.setTile(x,ay+11,z,Level.getTile(x,ay+10,z),Level.getData(x,ay+10,z));
}Level.setTile(x,ay+10,z,Level.getTile(x,ay+9,z),Level.getData(x,ay+9,z));
}Level.setTile(x,ay+9,z,Level.getTile(x,ay+8,z),Level.getData(x,ay+8,z));
}Level.setTile(x,ay+8,z,Level.getTile(x,ay+7,z),Level.getData(x,ay+7,z));
}Level.setTile(x,ay+7,z,Level.getTile(x,ay+6,z),Level.getData(x,ay+6,z));
}Level.setTile(x,ay+6,z,Level.getTile(x,ay+5,z),Level.getData(x,ay+5,z));
}Level.setTile(x,ay+5,z,Level.getTile(x,ay+4,z),Level.getData(x,ay+4,z));
}Level.setTile(x,ay+4,z,Level.getTile(x,ay+3,z),Level.getData(x,ay+3,z));
}Level.setTile(x,ay+3,z,Level.getTile(x,ay+2,z),Level.getData(x,ay+2,z));
}Level.setTile(x,ay+2,z,Level.getTile(x,ay+1,z),Level.getData(x,ay+1,z));
}Level.setTile(x,ay+1,z,0); }
if(Level.getTile(x,y+1,z)==0) {
Level.setTile(x,y,z,211,3);
Level.setTile(x,y+1,z,210,4);
Level.setTile(x,y+2,z,209,3);}
 
}
 else if(blockId==206 && blockData==4) {

Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az >z-2 ; az--) {
if(Level.getTile(x,y,az-1)>0) {
if(Level.getTile(x,y,az-2)>0) {
if(Level.getTile(x,y,az-3)>0) {
if(Level.getTile(x,y,az-4)>0) {
if(Level.getTile(x,y,az-5)>0) {
if(Level.getTile(x,y,az-6)>0) {
if(Level.getTile(x,y,az-7)>0) {
if(Level.getTile(x,y,az-8)>0) {
if(Level.getTile(x,y,az-9)>0) {
if(Level.getTile(x,y,az-10)>0) {
if(Level.getTile(x,y,az-11)>0) {
if(Level.getTile(x,y,az-12)>0) {
if(Level.getTile(x,y,az-13)>0) {
break;
}
Level.setTile(x,y,az-13,Level.getTile(x,y,az-12),Level.getData(x,y,az-12));
}Level.setTile(x,y,az-12,Level.getTile(x,y,az-11),Level.getData(x,y,az-11));
}Level.setTile(x,y,az-11,Level.getTile(x,y,az-10),Level.getData(x,y,az-10));
}Level.setTile(x,y,az-10,Level.getTile(x,y,az-9),Level.getData(x,y,az-9));
}Level.setTile(x,y,az-9,Level.getTile(x,y,az-8),Level.getData(x,y,az-8));
}Level.setTile(x,y,az-8,Level.getTile(x,y,az-7),Level.getData(x,y,az-7));
}Level.setTile(x,y,az-7,Level.getTile(x,y,az-6),Level.getData(x,y,az-6));
}Level.setTile(x,y,az-6,Level.getTile(x,y,az-5),Level.getData(x,y,az-5));
}Level.setTile(x,y,az-5,Level.getTile(x,y,az-4),Level.getData(x,y,az-4));
}Level.setTile(x,y,az-4,Level.getTile(x,y,az-3),Level.getData(x,y,az-3));
}Level.setTile(x,y,az-3,Level.getTile(x,y,az-2),Level.getData(x,y,az-2));
}Level.setTile(x,y,az-2,Level.getTile(x,y,az-1),Level.getData(x,y,az-1));
}Level.setTile(x,y,az-1,0); }
if(Level.getTile(x,y,z-1)==0) {
Level.setTile(x,y,z,211,1);
Level.setTile(x,y,z-1,210,2);
Level.setTile(x,y,z-2,209,2);}}
 else if(blockId==206 && blockData==5) {

Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az <z+2 ; az++) {
if(Level.getTile(x,y,az+1)>0) {
if(Level.getTile(x,y,az+2)>0) {
if(Level.getTile(x,y,az+3)>0) {
if(Level.getTile(x,y,az+4)>0) {
if(Level.getTile(x,y,az+5)>0) {
if(Level.getTile(x,y,az+6)>0) {
if(Level.getTile(x,y,az+7)>0) {
if(Level.getTile(x,y,az+8)>0) {
if(Level.getTile(x,y,az+9)>0) {
if(Level.getTile(x,y,az+10)>0) {
if(Level.getTile(x,y,az+11)>0) {
if(Level.getTile(x,y,az+12)>0) {
if(Level.getTile(x,y,az+13)>0) {
break;
}
Level.setTile(x,y,az+13,Level.getTile(x,y,az+12),Level.getData(x,y,az+12));
}Level.setTile(x,y,az+12,Level.getTile(x,y,az+11),Level.getData(x,y,az+11));
}Level.setTile(x,y,az+11,Level.getTile(x,y,az+10),Level.getData(x,y,az+10));
}Level.setTile(x,y,az+10,Level.getTile(x,y,az+9),Level.getData(x,y,az+9));
}Level.setTile(x,y,az+9,Level.getTile(x,y,az+8),Level.getData(x,y,az+8));
}Level.setTile(x,y,az+8,Level.getTile(x,y,az+7),Level.getData(x,y,az+7));
}Level.setTile(x,y,az+7,Level.getTile(x,y,az+6),Level.getData(x,y,az+6));
}Level.setTile(x,y,az+6,Level.getTile(x,y,az+5),Level.getData(x,y,az+5));
}Level.setTile(x,y,az+5,Level.getTile(x,y,az+4),Level.getData(x,y,az+4));
}Level.setTile(x,y,az+4,Level.getTile(x,y,az+3),Level.getData(x,y,az+3));
}Level.setTile(x,y,az+3,Level.getTile(x,y,az+2),Level.getData(x,y,az+2));
}Level.setTile(x,y,az+2,Level.getTile(x,y,az+1),Level.getData(x,y,az+1));
}Level.setTile(x,y,az+1,0); }
if(Level.getTile(x,y,z+1)==0) {
Level.setTile(x,y,z,211,2);
Level.setTile(x,y,z+1,210,3);
Level.setTile(x,y,z+2,209,1);}
}
else if(blockId==212 || blockId==216) {
if ( blockData==3) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax <x+3 ; ax++) {
if(Level.getTile(ax+1,y,z)>0) {
if(Level.getTile(ax+2,y,z)>0) {
if(Level.getTile(ax+3,y,z)>0) {
if(Level.getTile(ax+4,y,z)>0) {
if(Level.getTile(ax+5,y,z)>0) {
if(Level.getTile(ax+6,y,z)>0) {
if(Level.getTile(ax+7,y,z)>0) {
if(Level.getTile(ax+8,y,z)>0) {
if(Level.getTile(ax+9,y,z)>0) {
if(Level.getTile(ax+10,y,z)>0) {
if(Level.getTile(ax+11,y,z)>0) {
if(Level.getTile(ax+12,y,z)>0) {
if(Level.getTile(ax+13,y,z)>0) {
break;
}
Level.setTile(ax+13,y,z,Level.getTile(ax+12,y,z),Level.getData(ax+12,y,z));
}Level.setTile(ax+12,y,z,Level.getTile(ax+11,y,z),Level.getData(ax+11,y,z));
}Level.setTile(ax+11,y,z,Level.getTile(ax+10,y,z),Level.getData(ax+10,y,z));
}Level.setTile(ax+10,y,z,Level.getTile(ax+9,y,z),Level.getData(ax+9,y,z));
}Level.setTile(ax+9,y,z,Level.getTile(ax+8,y,z),Level.getData(ax+8,y,z));
}Level.setTile(ax+8,y,z,Level.getTile(ax+7,y,z),Level.getData(ax+7,y,z));
}Level.setTile(ax+7,y,z,Level.getTile(ax+6,y,z),Level.getData(ax+6,y,z));
}Level.setTile(ax+6,y,z,Level.getTile(ax+5,y,z),Level.getData(ax+5,y,z));
}Level.setTile(ax+5,y,z,Level.getTile(ax+4,y,z),Level.getData(ax+4,y,z));
}Level.setTile(ax+4,y,z,Level.getTile(ax+3,y,z),Level.getData(ax+3,y,z));
}Level.setTile(ax+3,y,z,Level.getTile(ax+2,y,z),Level.getData(ax+2,y,z));
}Level.setTile(ax+2,y,z,Level.getTile(ax+1,y,z),Level.getData(ax+1,y,z));
}Level.setTile(ax+1,y,z,0); }
if(Level.getTile(x+1,y,z)==0) {
if(blockId==212){
Level.setTile(x,y,z,213,5);
Level.setTile(x+1,y,z,214,0);
Level.setTile(x+2,y,z,201,0);
Level.setTile(x+3,y,z,209,0);
} else if(blockId==216){
Level.setTile(x,y,z,215,5);
Level.setTile(x+1,y,z,214,0);
Level.setTile(x+2,y,z,201,0);
Level.setTile(x+3,y,z,203,0);
}
}}
 else if( blockData==0) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
 ax=x;
for (ax ; ax >x-3 ; ax--) {
if(Level.getTile(ax-1,y,z)>0) {
if(Level.getTile(ax-2,y,z)>0) {
if(Level.getTile(ax-3,y,z)>0) {
if(Level.getTile(ax-4,y,z)>0) {
if(Level.getTile(ax-5,y,z)>0) {
if(Level.getTile(ax-6,y,z)>0) {
if(Level.getTile(ax-7,y,z)>0) {
if(Level.getTile(ax-8,y,z)>0) {
if(Level.getTile(ax-9,y,z)>0) {
if(Level.getTile(ax-10,y,z)>0) {
if(Level.getTile(ax-11,y,z)>0) {
if(Level.getTile(ax-12,y,z)>0) {
if(Level.getTile(ax-13,y,z)>0) {
break;
}
Level.setTile(ax-13,y,z,Level.getTile(ax-12,y,z),Level.getData(ax-12,y,z));
}Level.setTile(ax-12,y,z,Level.getTile(ax-11,y,z),Level.getData(ax-11,y,z));
}Level.setTile(ax-11,y,z,Level.getTile(ax-10,y,z),Level.getData(ax-10,y,z));
}Level.setTile(ax-10,y,z,Level.getTile(ax-9,y,z),Level.getData(ax-9,y,z));
}Level.setTile(ax-9,y,z,Level.getTile(ax-8,y,z),Level.getData(ax-8,y,z));
}Level.setTile(ax-8,y,z,Level.getTile(ax-7,y,z),Level.getData(ax-7,y,z));
}Level.setTile(ax-7,y,z,Level.getTile(ax-6,y,z),Level.getData(ax-6,y,z));
}Level.setTile(ax-6,y,z,Level.getTile(ax-5,y,z),Level.getData(ax-5,y,z));
}Level.setTile(ax-5,y,z,Level.getTile(ax-4,y,z),Level.getData(ax-4,y,z));
}Level.setTile(ax-4,y,z,Level.getTile(ax-3,y,z),Level.getData(ax-3,y,z));
}Level.setTile(ax-3,y,z,Level.getTile(ax-2,y,z),Level.getData(ax-2,y,z));
}Level.setTile(ax-2,y,z,Level.getTile(ax-1,y,z),Level.getData(ax-1,y,z));
}Level.setTile(ax-1,y,z,0); }
if(Level.getTile(x-1,y,z)==0) {
if(blockId==212){
Level.setTile(x,y,z,213,0);
Level.setTile(x-1,y,z,214,1);
Level.setTile(x-2,y,z,201,1);
Level.setTile(x-3,y,z,209,5);}
else if(blockId==216) {
Level.setTile(x,y,z,215,0);
Level.setTile(x-1,y,z,214,1);
Level.setTile(x-2,y,z,201,1);
Level.setTile(x-3,y,z,207,0);
}
}} 
else if(blockData==1) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay >y-3 ; ay--) {
if(Level.getTile(x,ay-1,z)>0) {
if(Level.getTile(x,ay-2,z)>0) {
if(Level.getTile(x,ay-3,z)>0) {
if(Level.getTile(x,ay-4,z)>0) {
if(Level.getTile(x,ay-5,z)>0) {
if(Level.getTile(x,ay-6,z)>0) {
if(Level.getTile(x,ay-7,z)>0) {
if(Level.getTile(x,ay-8,z)>0) {
if(Level.getTile(x,ay-9,z)>0) {
if(Level.getTile(x,ay-10,z)>0) {
if(Level.getTile(x,ay-11,z)>0) {
if(Level.getTile(x,ay-12,z)>0) {
if(Level.getTile(x,ay-13,z)>0) {
break;
}
Level.setTile(x,ay-13,z,Level.getTile(x,ay-12,z),Level.getData(x,ay-13,z));
}Level.setTile(x,ay-12,z,Level.getTile(x,ay-11,z),Level.getData(x,ay-11,z));
}Level.setTile(x,ay-11,z,Level.getTile(x,ay-10,z),Level.getData(x,ay-10,z));
}Level.setTile(x,ay-10,z,Level.getTile(x,ay-9,z),Level.getData(x,ay-9,z));
}Level.setTile(x,ay-9,z,Level.getTile(x,ay-8,z),Level.getData(x,ay-8,z));
}Level.setTile(x,ay-8,z,Level.getTile(x,ay-7,z),Level.getData(x,ay-7,z));
}Level.setTile(x,ay-7,z,Level.getTile(x,ay-6,z),Level.getData(x,ay-6,z));
}Level.setTile(x,ay-6,z,Level.getTile(x,ay-5,z),Level.getData(x,ay-5,z));
}Level.setTile(x,ay-5,z,Level.getTile(x,ay-4,z),Level.getData(x,ay-4,z));
}Level.setTile(x,ay-4,z,Level.getTile(x,ay-3,z),Level.getData(x,ay-3,z));
}Level.setTile(x,ay-3,z,Level.getTile(x,ay-2,z),Level.getData(x,ay-2,z));
}Level.setTile(x,ay-2,z,Level.getTile(x,ay-1,z),Level.getData(x,ay-1,z));
}Level.setTile(x,ay-1,z,0); }
if(Level.getTile(x,y-1,z)==0) {
if(blockId==212){
Level.setTile(x,y,z,213,4);
Level.setTile(x,y-2,z,210,5);
Level.setTile(x,y-3,z,209,4);
Level.setTile(x,y-1,z,214,5);}
else if(blockId==216){
Level.setTile(x,y,z,215,4);
Level.setTile(x,y-2,z,210,5);
Level.setTile(x,y-3,z,203,4);
Level.setTile(x,y-1,z,214,5);
}
}  }
else if(blockData==2) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay <y+3 ; ay++) {
if(Level.getTile(x,ay+1,z)>0) {
if(Level.getTile(x,ay+2,z)>0) {
if(Level.getTile(x,ay+3,z)>0) {
if(Level.getTile(x,ay+4,z)>0) {
if(Level.getTile(x,ay+5,z)>0) {
if(Level.getTile(x,ay+6,z)>0) {
if(Level.getTile(x,ay+7,z)>0) {
if(Level.getTile(x,ay+8,z)>0) {
if(Level.getTile(x,ay+9,z)>0) {
if(Level.getTile(x,ay+10,z)>0) {
if(Level.getTile(x,ay+11,z)>0) {
if(Level.getTile(x,ay+12,z)>0) {
if(Level.getTile(x,ay+13,z)>0) {
break;
}
Level.setTile(x,ay+13,z,Level.getTile(x,ay+12,z),Level.getData(x,ay+13,z));
}Level.setTile(x,ay+12,z,Level.getTile(x,ay+11,z),Level.getData(x,ay+11,z));
}Level.setTile(x,ay+11,z,Level.getTile(x,ay+10,z),Level.getData(x,ay+10,z));
}Level.setTile(x,ay+10,z,Level.getTile(x,ay+9,z),Level.getData(x,ay+9,z));
}Level.setTile(x,ay+9,z,Level.getTile(x,ay+8,z),Level.getData(x,ay+8,z));
}Level.setTile(x,ay+8,z,Level.getTile(x,ay+7,z),Level.getData(x,ay+7,z));
}Level.setTile(x,ay+7,z,Level.getTile(x,ay+6,z),Level.getData(x,ay+6,z));
}Level.setTile(x,ay+6,z,Level.getTile(x,ay+5,z),Level.getData(x,ay+5,z));
}Level.setTile(x,ay+5,z,Level.getTile(x,ay+4,z),Level.getData(x,ay+4,z));
}Level.setTile(x,ay+4,z,Level.getTile(x,ay+3,z),Level.getData(x,ay+3,z));
}Level.setTile(x,ay+3,z,Level.getTile(x,ay+2,z),Level.getData(x,ay+2,z));
}Level.setTile(x,ay+2,z,Level.getTile(x,ay+1,z),Level.getData(x,ay+1,z));
}Level.setTile(x,ay+1,z,0); }
if(Level.getTile(x,y+1,z)==0) {
if(blockId==212) {
Level.setTile(x,y,z,213,3);
Level.setTile(x,y+2,z,201,4);
Level.setTile(x,y+3,z,209,3);
Level.setTile(x,y+1,z,214,4);}
if(blockId==216) {
Level.setTile(x,y,z,215,3);
Level.setTile(x,y+2,z,201,4);
Level.setTile(x,y+3,z,203,3);
Level.setTile(x,y+1,z,214,4);
}}
} 
else if(blockData==4) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az >z-3 ; az--) {
if(Level.getTile(x,y,az-1)>0) {
if(Level.getTile(x,y,az-2)>0) {
if(Level.getTile(x,y,az-3)>0) {
if(Level.getTile(x,y,az-4)>0) {
if(Level.getTile(x,y,az-5)>0) {
if(Level.getTile(x,y,az-6)>0) {
if(Level.getTile(x,y,az-7)>0) {
if(Level.getTile(x,y,az-8)>0) {
if(Level.getTile(x,y,az-9)>0) {
if(Level.getTile(x,y,az-10)>0) {
if(Level.getTile(x,y,az-11)>0) {
if(Level.getTile(x,y,az-12)>0) {
if(Level.getTile(x,y,az-13)>0) {
break;
}
Level.setTile(x,y,az-13,Level.getTile(x,y,az-12),Level.getData(x,y,az-12));
}Level.setTile(x,y,az-12,Level.getTile(x,y,az-11),Level.getData(x,y,az-11));
}Level.setTile(x,y,az-11,Level.getTile(x,y,az-10),Level.getData(x,y,az-10));
}Level.setTile(x,y,az-10,Level.getTile(x,y,az-9),Level.getData(x,y,az-9));
}Level.setTile(x,y,az-9,Level.getTile(x,y,az-8),Level.getData(x,y,az-8));
}Level.setTile(x,y,az-8,Level.getTile(x,y,az-7),Level.getData(x,y,az-7));
}Level.setTile(x,y,az-7,Level.getTile(x,y,az-6),Level.getData(x,y,az-6));
}Level.setTile(x,y,az-6,Level.getTile(x,y,az-5),Level.getData(x,y,az-5));
}Level.setTile(x,y,az-5,Level.getTile(x,y,az-4),Level.getData(x,y,az-4));
}Level.setTile(x,y,az-4,Level.getTile(x,y,az-3),Level.getData(x,y,az-3));
}Level.setTile(x,y,az-3,Level.getTile(x,y,az-2),Level.getData(x,y,az-2));
}Level.setTile(x,y,az-2,Level.getTile(x,y,az-1),Level.getData(x,y,az-1));
}Level.setTile(x,y,az-1,0); }
if(Level.getTile(x,y,z-1)==0) {
if(blockId==212) {
Level.setTile(x,y,z,213,1);
Level.setTile(x,y,z-1,214,3);
Level.setTile(x,y,z-2,201,2);
Level.setTile(x,y,z-3,209,2);}
if(blockId==216){
Level.setTile(x,y,z,215,1);
Level.setTile(x,y,z-1,214,3);
Level.setTile(x,y,z-2,201,2);
Level.setTile(x,y,z-3,203,2);
}}
} 
else if(blockData==5) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az <z+3 ; az++) {
if(Level.getTile(x,y,az+1)>0) {
if(Level.getTile(x,y,az+2)>0) {
if(Level.getTile(x,y,az+3)>0) {
if(Level.getTile(x,y,az+4)>0) {
if(Level.getTile(x,y,az+5)>0) {
if(Level.getTile(x,y,az+6)>0) {
if(Level.getTile(x,y,az+7)>0) {
if(Level.getTile(x,y,az+8)>0) {
if(Level.getTile(x,y,az+9)>0) {
if(Level.getTile(x,y,az+10)>0) {
if(Level.getTile(x,y,az+11)>0) {
if(Level.getTile(x,y,az+12)>0) {
if(Level.getTile(x,y,az+13)>0) {
break;
}
Level.setTile(x,y,az+13,Level.getTile(x,y,az+12),Level.getData(x,y,az+12));
}Level.setTile(x,y,az+12,Level.getTile(x,y,az+11),Level.getData(x,y,az+11));
}Level.setTile(x,y,az+11,Level.getTile(x,y,az+10),Level.getData(x,y,az+10));
}Level.setTile(x,y,az+10,Level.getTile(x,y,az+9),Level.getData(x,y,az+9));
}Level.setTile(x,y,az+9,Level.getTile(x,y,az+8),Level.getData(x,y,az+8));
}Level.setTile(x,y,az+8,Level.getTile(x,y,az+7),Level.getData(x,y,az+7));
}Level.setTile(x,y,az+7,Level.getTile(x,y,az+6),Level.getData(x,y,az+6));
}Level.setTile(x,y,az+6,Level.getTile(x,y,az+5),Level.getData(x,y,az+5));
}Level.setTile(x,y,az+5,Level.getTile(x,y,az+4),Level.getData(x,y,az+4));
}Level.setTile(x,y,az+4,Level.getTile(x,y,az+3),Level.getData(x,y,az+3));
}Level.setTile(x,y,az+3,Level.getTile(x,y,az+2),Level.getData(x,y,az+2));
}Level.setTile(x,y,az+2,Level.getTile(x,y,az+1),Level.getData(x,y,az+1));
}Level.setTile(x,y,az+1,0); }
if(Level.getTile(x,y,z+1)==0) {
if(blockId==212) {
Level.setTile(x,y,z,213,2);
Level.setTile(x,y,z+1,214,2);
Level.setTile(x,y,z+2,201,3);
Level.setTile(x,y,z+3,209,1);}
if(blockId==216) {
Level.setTile(x,y,z,215,2);
Level.setTile(x,y,z+1,214,2);
Level.setTile(x,y,z+2,201,3);
Level.setTile(x,y,z+3,203,1);
}
}
}
}

else if(blockId==217 || blockId==218) {
if ( blockData==3) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax <x+4 ; ax++) {
if(Level.getTile(ax+1,y,z)>0) {
if(Level.getTile(ax+2,y,z)>0) {
if(Level.getTile(ax+3,y,z)>0) {
if(Level.getTile(ax+4,y,z)>0) {
if(Level.getTile(ax+5,y,z)>0) {
if(Level.getTile(ax+6,y,z)>0) {
if(Level.getTile(ax+7,y,z)>0) {
if(Level.getTile(ax+8,y,z)>0) {
if(Level.getTile(ax+9,y,z)>0) {
if(Level.getTile(ax+10,y,z)>0) {
if(Level.getTile(ax+11,y,z)>0) {
if(Level.getTile(ax+12,y,z)>0) {
if(Level.getTile(ax+13,y,z)>0) {
break;
}
Level.setTile(ax+13,y,z,Level.getTile(ax+12,y,z),Level.getData(ax+12,y,z));
}Level.setTile(ax+12,y,z,Level.getTile(ax+11,y,z),Level.getData(ax+11,y,z));
}Level.setTile(ax+11,y,z,Level.getTile(ax+10,y,z),Level.getData(ax+10,y,z));
}Level.setTile(ax+10,y,z,Level.getTile(ax+9,y,z),Level.getData(ax+9,y,z));
}Level.setTile(ax+9,y,z,Level.getTile(ax+8,y,z),Level.getData(ax+8,y,z));
}Level.setTile(ax+8,y,z,Level.getTile(ax+7,y,z),Level.getData(ax+7,y,z));
}Level.setTile(ax+7,y,z,Level.getTile(ax+6,y,z),Level.getData(ax+6,y,z));
}Level.setTile(ax+6,y,z,Level.getTile(ax+5,y,z),Level.getData(ax+5,y,z));
}Level.setTile(ax+5,y,z,Level.getTile(ax+4,y,z),Level.getData(ax+4,y,z));
}Level.setTile(ax+4,y,z,Level.getTile(ax+3,y,z),Level.getData(ax+3,y,z));
}Level.setTile(ax+3,y,z,Level.getTile(ax+2,y,z),Level.getData(ax+2,y,z));
}Level.setTile(ax+2,y,z,Level.getTile(ax+1,y,z),Level.getData(ax+1,y,z));
}Level.setTile(ax+1,y,z,0); }
if(Level.getTile(x+1,y,z)==0) {
if(blockId==217){
Level.setTile(x,y,z,219,5);
Level.setTile(x+1,y,z,214,6);
Level.setTile(x+2,y,z,201,6);
Level.setTile(x+3,y,z,201,7);
Level.setTile(x+4,y,z,209,0);
} else if(blockId==218){
Level.setTile(x,y,z,220,5);
Level.setTile(x+1,y,z,214,6);
Level.setTile(x+2,y,z,201,6);
Level.setTile(x+3,y,z,201,7);
Level.setTile(x+4,y,z,203,0);
}
}}
 else if( blockData==0) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
 ax=x;
for (ax ; ax >x-4 ; ax--) {
if(Level.getTile(ax-1,y,z)>0) {
if(Level.getTile(ax-2,y,z)>0) {
if(Level.getTile(ax-3,y,z)>0) {
if(Level.getTile(ax-4,y,z)>0) {
if(Level.getTile(ax-5,y,z)>0) {
if(Level.getTile(ax-6,y,z)>0) {
if(Level.getTile(ax-7,y,z)>0) {
if(Level.getTile(ax-8,y,z)>0) {
if(Level.getTile(ax-9,y,z)>0) {
if(Level.getTile(ax-10,y,z)>0) {
if(Level.getTile(ax-11,y,z)>0) {
if(Level.getTile(ax-12,y,z)>0) {
if(Level.getTile(ax-13,y,z)>0) {
break;
}
Level.setTile(ax-13,y,z,Level.getTile(ax-12,y,z),Level.getData(ax-12,y,z));
}Level.setTile(ax-12,y,z,Level.getTile(ax-11,y,z),Level.getData(ax-11,y,z));
}Level.setTile(ax-11,y,z,Level.getTile(ax-10,y,z),Level.getData(ax-10,y,z));
}Level.setTile(ax-10,y,z,Level.getTile(ax-9,y,z),Level.getData(ax-9,y,z));
}Level.setTile(ax-9,y,z,Level.getTile(ax-8,y,z),Level.getData(ax-8,y,z));
}Level.setTile(ax-8,y,z,Level.getTile(ax-7,y,z),Level.getData(ax-7,y,z));
}Level.setTile(ax-7,y,z,Level.getTile(ax-6,y,z),Level.getData(ax-6,y,z));
}Level.setTile(ax-6,y,z,Level.getTile(ax-5,y,z),Level.getData(ax-5,y,z));
}Level.setTile(ax-5,y,z,Level.getTile(ax-4,y,z),Level.getData(ax-4,y,z));
}Level.setTile(ax-4,y,z,Level.getTile(ax-3,y,z),Level.getData(ax-3,y,z));
}Level.setTile(ax-3,y,z,Level.getTile(ax-2,y,z),Level.getData(ax-2,y,z));
}Level.setTile(ax-2,y,z,Level.getTile(ax-1,y,z),Level.getData(ax-1,y,z));
}Level.setTile(ax-1,y,z,0); }
if(Level.getTile(x-1,y,z)==0) {
if(blockId==217){
Level.setTile(x,y,z,219,0);
Level.setTile(x-1,y,z,214,7);
Level.setTile(x-2,y,z,201,8);
Level.setTile(x-3,y,z,201,9);
Level.setTile(x-4,y,z,209,5);}
else if(blockId==218) {
Level.setTile(x,y,z,220,0);
Level.setTile(x-1,y,z,214,7);
Level.setTile(x-2,y,z,201,8);
Level.setTile(x-3,y,z,201,9);
Level.setTile(x-4,y,z,207,0);
}
}} 
else if(blockData==1) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay >y-4 ; ay--) {
if(Level.getTile(x,ay-1,z)>0) {
if(Level.getTile(x,ay-2,z)>0) {
if(Level.getTile(x,ay-3,z)>0) {
if(Level.getTile(x,ay-4,z)>0) {
if(Level.getTile(x,ay-5,z)>0) {
if(Level.getTile(x,ay-6,z)>0) {
if(Level.getTile(x,ay-7,z)>0) {
if(Level.getTile(x,ay-8,z)>0) {
if(Level.getTile(x,ay-9,z)>0) {
if(Level.getTile(x,ay-10,z)>0) {
if(Level.getTile(x,ay-11,z)>0) {
if(Level.getTile(x,ay-12,z)>0) {
if(Level.getTile(x,ay-13,z)>0) {
break;
}
Level.setTile(x,ay-13,z,Level.getTile(x,ay-12,z),Level.getData(x,ay-13,z));
}Level.setTile(x,ay-12,z,Level.getTile(x,ay-11,z),Level.getData(x,ay-11,z));
}Level.setTile(x,ay-11,z,Level.getTile(x,ay-10,z),Level.getData(x,ay-10,z));
}Level.setTile(x,ay-10,z,Level.getTile(x,ay-9,z),Level.getData(x,ay-9,z));
}Level.setTile(x,ay-9,z,Level.getTile(x,ay-8,z),Level.getData(x,ay-8,z));
}Level.setTile(x,ay-8,z,Level.getTile(x,ay-7,z),Level.getData(x,ay-7,z));
}Level.setTile(x,ay-7,z,Level.getTile(x,ay-6,z),Level.getData(x,ay-6,z));
}Level.setTile(x,ay-6,z,Level.getTile(x,ay-5,z),Level.getData(x,ay-5,z));
}Level.setTile(x,ay-5,z,Level.getTile(x,ay-4,z),Level.getData(x,ay-4,z));
}Level.setTile(x,ay-4,z,Level.getTile(x,ay-3,z),Level.getData(x,ay-3,z));
}Level.setTile(x,ay-3,z,Level.getTile(x,ay-2,z),Level.getData(x,ay-2,z));
}Level.setTile(x,ay-2,z,Level.getTile(x,ay-1,z),Level.getData(x,ay-1,z));
}Level.setTile(x,ay-1,z,0); }
if(Level.getTile(x,y-1,z)==0) {
if(blockId==217){
Level.setTile(x,y,z,219,4);
Level.setTile(x,y-2,z,210,6);
Level.setTile(x,y-3,z,210,7);
Level.setTile(x,y-4,z,209,4);
Level.setTile(x,y-1,z,214,11);}
else if(blockId==218){
Level.setTile(x,y,z,220,4);
Level.setTile(x,y-2,z,210,6);
Level.setTile(x,y-3,z,210,7);
Level.setTile(x,y-4,z,203,4);
Level.setTile(x,y-1,z,214,11);
}
}  }
else if(blockData==2) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay <y+4 ; ay++) {
if(Level.getTile(x,ay+1,z)>0) {
if(Level.getTile(x,ay+2,z)>0) {
if(Level.getTile(x,ay+3,z)>0) {
if(Level.getTile(x,ay+4,z)>0) {
if(Level.getTile(x,ay+5,z)>0) {
if(Level.getTile(x,ay+6,z)>0) {
if(Level.getTile(x,ay+7,z)>0) {
if(Level.getTile(x,ay+8,z)>0) {
if(Level.getTile(x,ay+9,z)>0) {
if(Level.getTile(x,ay+10,z)>0) {
if(Level.getTile(x,ay+11,z)>0) {
if(Level.getTile(x,ay+12,z)>0) {
if(Level.getTile(x,ay+13,z)>0) {
break;
}
Level.setTile(x,ay+13,z,Level.getTile(x,ay+12,z),Level.getData(x,ay+13,z));
}Level.setTile(x,ay+12,z,Level.getTile(x,ay+11,z),Level.getData(x,ay+11,z));
}Level.setTile(x,ay+11,z,Level.getTile(x,ay+10,z),Level.getData(x,ay+10,z));
}Level.setTile(x,ay+10,z,Level.getTile(x,ay+9,z),Level.getData(x,ay+9,z));
}Level.setTile(x,ay+9,z,Level.getTile(x,ay+8,z),Level.getData(x,ay+8,z));
}Level.setTile(x,ay+8,z,Level.getTile(x,ay+7,z),Level.getData(x,ay+7,z));
}Level.setTile(x,ay+7,z,Level.getTile(x,ay+6,z),Level.getData(x,ay+6,z));
}Level.setTile(x,ay+6,z,Level.getTile(x,ay+5,z),Level.getData(x,ay+5,z));
}Level.setTile(x,ay+5,z,Level.getTile(x,ay+4,z),Level.getData(x,ay+4,z));
}Level.setTile(x,ay+4,z,Level.getTile(x,ay+3,z),Level.getData(x,ay+3,z));
}Level.setTile(x,ay+3,z,Level.getTile(x,ay+2,z),Level.getData(x,ay+2,z));
}Level.setTile(x,ay+2,z,Level.getTile(x,ay+1,z),Level.getData(x,ay+1,z));
}Level.setTile(x,ay+1,z,0); }
if(Level.getTile(x,y+1,z)==0) {
if(blockId==217) {
Level.setTile(x,y,z,219,3);
Level.setTile(x,y+2,z,201,14);
Level.setTile(x,y+3,z,201,15);
Level.setTile(x,y+4,z,209,3);
Level.setTile(x,y+1,z,214,10);}
if(blockId==218) {
Level.setTile(x,y,z,220,3);
Level.setTile(x,y+2,z,201,14);
Level.setTile(x,y+3,z,201,15);
Level.setTile(x,y+4,z,203,3);
Level.setTile(x,y+1,z,214,10);
}}
} 
else if(blockData==4) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az >z-4 ; az--) {
if(Level.getTile(x,y,az-1)>0) {
if(Level.getTile(x,y,az-2)>0) {
if(Level.getTile(x,y,az-3)>0) {
if(Level.getTile(x,y,az-4)>0) {
if(Level.getTile(x,y,az-5)>0) {
if(Level.getTile(x,y,az-6)>0) {
if(Level.getTile(x,y,az-7)>0) {
if(Level.getTile(x,y,az-8)>0) {
if(Level.getTile(x,y,az-9)>0) {
if(Level.getTile(x,y,az-10)>0) {
if(Level.getTile(x,y,az-11)>0) {
if(Level.getTile(x,y,az-12)>0) {
if(Level.getTile(x,y,az-13)>0) {
break;
}
Level.setTile(x,y,az-13,Level.getTile(x,y,az-12),Level.getData(x,y,az-12));
}Level.setTile(x,y,az-12,Level.getTile(x,y,az-11),Level.getData(x,y,az-11));
}Level.setTile(x,y,az-11,Level.getTile(x,y,az-10),Level.getData(x,y,az-10));
}Level.setTile(x,y,az-10,Level.getTile(x,y,az-9),Level.getData(x,y,az-9));
}Level.setTile(x,y,az-9,Level.getTile(x,y,az-8),Level.getData(x,y,az-8));
}Level.setTile(x,y,az-8,Level.getTile(x,y,az-7),Level.getData(x,y,az-7));
}Level.setTile(x,y,az-7,Level.getTile(x,y,az-6),Level.getData(x,y,az-6));
}Level.setTile(x,y,az-6,Level.getTile(x,y,az-5),Level.getData(x,y,az-5));
}Level.setTile(x,y,az-5,Level.getTile(x,y,az-4),Level.getData(x,y,az-4));
}Level.setTile(x,y,az-4,Level.getTile(x,y,az-3),Level.getData(x,y,az-3));
}Level.setTile(x,y,az-3,Level.getTile(x,y,az-2),Level.getData(x,y,az-2));
}Level.setTile(x,y,az-2,Level.getTile(x,y,az-1),Level.getData(x,y,az-1));
}Level.setTile(x,y,az-1,0); }
if(Level.getTile(x,y,z-1)==0) {
if(blockId==217) {
Level.setTile(x,y,z,219,1);
Level.setTile(x,y,z-1,214,9);
Level.setTile(x,y,z-2,201,12);
Level.setTile(x,y,z-3,201,13);
Level.setTile(x,y,z-4,209,2);}
if(blockId==218){
Level.setTile(x,y,z,220,1);
Level.setTile(x,y,z-1,214,9);
Level.setTile(x,y,z-2,201,12);
Level.setTile(x,y,z-3,201,13);
Level.setTile(x,y,z-4,203,2);
}}
} 
else if(blockData==5) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az <z+4 ; az++) {
if(Level.getTile(x,y,az+1)>0) {
if(Level.getTile(x,y,az+2)>0) {
if(Level.getTile(x,y,az+3)>0) {
if(Level.getTile(x,y,az+4)>0) {
if(Level.getTile(x,y,az+5)>0) {
if(Level.getTile(x,y,az+6)>0) {
if(Level.getTile(x,y,az+7)>0) {
if(Level.getTile(x,y,az+8)>0) {
if(Level.getTile(x,y,az+9)>0) {
if(Level.getTile(x,y,az+10)>0) {
if(Level.getTile(x,y,az+11)>0) {
if(Level.getTile(x,y,az+12)>0) {
if(Level.getTile(x,y,az+13)>0) {
break;
}
Level.setTile(x,y,az+13,Level.getTile(x,y,az+12),Level.getData(x,y,az+12));
}Level.setTile(x,y,az+12,Level.getTile(x,y,az+11),Level.getData(x,y,az+11));
}Level.setTile(x,y,az+11,Level.getTile(x,y,az+10),Level.getData(x,y,az+10));
}Level.setTile(x,y,az+10,Level.getTile(x,y,az+9),Level.getData(x,y,az+9));
}Level.setTile(x,y,az+9,Level.getTile(x,y,az+8),Level.getData(x,y,az+8));
}Level.setTile(x,y,az+8,Level.getTile(x,y,az+7),Level.getData(x,y,az+7));
}Level.setTile(x,y,az+7,Level.getTile(x,y,az+6),Level.getData(x,y,az+6));
}Level.setTile(x,y,az+6,Level.getTile(x,y,az+5),Level.getData(x,y,az+5));
}Level.setTile(x,y,az+5,Level.getTile(x,y,az+4),Level.getData(x,y,az+4));
}Level.setTile(x,y,az+4,Level.getTile(x,y,az+3),Level.getData(x,y,az+3));
}Level.setTile(x,y,az+3,Level.getTile(x,y,az+2),Level.getData(x,y,az+2));
}Level.setTile(x,y,az+2,Level.getTile(x,y,az+1),Level.getData(x,y,az+1));
}Level.setTile(x,y,az+1,0); }
if(Level.getTile(x,y,z+1)==0) {
if(blockId==217) {
Level.setTile(x,y,z,219,2);
Level.setTile(x,y,z+1,214,8);
Level.setTile(x,y,z+2,201,10);
Level.setTile(x,y,z+3,201,11);
Level.setTile(x,y,z+4,209,1);}
if(blockId==218) {
Level.setTile(x,y,z,220,2);
Level.setTile(x,y,z+1,214,8);
Level.setTile(x,y,z+2,201,10);
Level.setTile(x,y,z+3,201,11);
Level.setTile(x,y,z+4,203,1);
}
}
}
}
else if(blockId==221 || blockId==222) {
if ( blockData==3) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax <x+5 ; ax++) {
if(Level.getTile(ax+1,y,z)>0) {
if(Level.getTile(ax+2,y,z)>0) {
if(Level.getTile(ax+3,y,z)>0) {
if(Level.getTile(ax+4,y,z)>0) {
if(Level.getTile(ax+5,y,z)>0) {
if(Level.getTile(ax+6,y,z)>0) {
if(Level.getTile(ax+7,y,z)>0) {
if(Level.getTile(ax+8,y,z)>0) {
if(Level.getTile(ax+9,y,z)>0) {
if(Level.getTile(ax+10,y,z)>0) {
if(Level.getTile(ax+11,y,z)>0) {
if(Level.getTile(ax+12,y,z)>0) {
if(Level.getTile(ax+13,y,z)>0) {
break;
}
Level.setTile(ax+13,y,z,Level.getTile(ax+12,y,z),Level.getData(ax+12,y,z));
}Level.setTile(ax+12,y,z,Level.getTile(ax+11,y,z),Level.getData(ax+11,y,z));
}Level.setTile(ax+11,y,z,Level.getTile(ax+10,y,z),Level.getData(ax+10,y,z));
}Level.setTile(ax+10,y,z,Level.getTile(ax+9,y,z),Level.getData(ax+9,y,z));
}Level.setTile(ax+9,y,z,Level.getTile(ax+8,y,z),Level.getData(ax+8,y,z));
}Level.setTile(ax+8,y,z,Level.getTile(ax+7,y,z),Level.getData(ax+7,y,z));
}Level.setTile(ax+7,y,z,Level.getTile(ax+6,y,z),Level.getData(ax+6,y,z));
}Level.setTile(ax+6,y,z,Level.getTile(ax+5,y,z),Level.getData(ax+5,y,z));
}Level.setTile(ax+5,y,z,Level.getTile(ax+4,y,z),Level.getData(ax+4,y,z));
}Level.setTile(ax+4,y,z,Level.getTile(ax+3,y,z),Level.getData(ax+3,y,z));
}Level.setTile(ax+3,y,z,Level.getTile(ax+2,y,z),Level.getData(ax+2,y,z));
}Level.setTile(ax+2,y,z,Level.getTile(ax+1,y,z),Level.getData(ax+1,y,z));
}Level.setTile(ax+1,y,z,0); }
if(Level.getTile(x+1,y,z)==0) {
if(blockId==221){
Level.setTile(x,y,z,223,5);
Level.setTile(x+1,y,z,214,6);
Level.setTile(x+2,y,z,201,6);
Level.setTile(x+3,y,z,201,7);
Level.setTile(x+5,y,z,209,0);
Level.setTile(x+4,y,z,210,8);
} else if(blockId==222){
Level.setTile(x,y,z,224,5);
Level.setTile(x+1,y,z,214,6);
Level.setTile(x+2,y,z,201,6);
Level.setTile(x+3,y,z,201,7);
Level.setTile(x+5,y,z,203,0);
Level.setTile(x+4,y,z,210,8);
}
}}
 else if( blockData==0) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
 ax=x;
for (ax ; ax >x-5 ; ax--) {
if(Level.getTile(ax-1,y,z)>0) {
if(Level.getTile(ax-2,y,z)>0) {
if(Level.getTile(ax-3,y,z)>0) {
if(Level.getTile(ax-4,y,z)>0) {
if(Level.getTile(ax-5,y,z)>0) {
if(Level.getTile(ax-6,y,z)>0) {
if(Level.getTile(ax-7,y,z)>0) {
if(Level.getTile(ax-8,y,z)>0) {
if(Level.getTile(ax-9,y,z)>0) {
if(Level.getTile(ax-10,y,z)>0) {
if(Level.getTile(ax-11,y,z)>0) {
if(Level.getTile(ax-12,y,z)>0) {
if(Level.getTile(ax-13,y,z)>0) {
break;
}
Level.setTile(ax-13,y,z,Level.getTile(ax-12,y,z),Level.getData(ax-12,y,z));
}Level.setTile(ax-12,y,z,Level.getTile(ax-11,y,z),Level.getData(ax-11,y,z));
}Level.setTile(ax-11,y,z,Level.getTile(ax-10,y,z),Level.getData(ax-10,y,z));
}Level.setTile(ax-10,y,z,Level.getTile(ax-9,y,z),Level.getData(ax-9,y,z));
}Level.setTile(ax-9,y,z,Level.getTile(ax-8,y,z),Level.getData(ax-8,y,z));
}Level.setTile(ax-8,y,z,Level.getTile(ax-7,y,z),Level.getData(ax-7,y,z));
}Level.setTile(ax-7,y,z,Level.getTile(ax-6,y,z),Level.getData(ax-6,y,z));
}Level.setTile(ax-6,y,z,Level.getTile(ax-5,y,z),Level.getData(ax-5,y,z));
}Level.setTile(ax-5,y,z,Level.getTile(ax-4,y,z),Level.getData(ax-4,y,z));
}Level.setTile(ax-4,y,z,Level.getTile(ax-3,y,z),Level.getData(ax-3,y,z));
}Level.setTile(ax-3,y,z,Level.getTile(ax-2,y,z),Level.getData(ax-2,y,z));
}Level.setTile(ax-2,y,z,Level.getTile(ax-1,y,z),Level.getData(ax-1,y,z));
}Level.setTile(ax-1,y,z,0); }
if(Level.getTile(x-1,y,z)==0) {
if(blockId==221){
Level.setTile(x,y,z,223,0);
Level.setTile(x-1,y,z,214,7);
Level.setTile(x-2,y,z,201,8);
Level.setTile(x-3,y,z,201,9);
Level.setTile(x-5,y,z,209,5);
Level.setTile(x-4,y,z,210,9);}
else if(blockId==222) {
Level.setTile(x,y,z,224,0);
Level.setTile(x-1,y,z,214,7);
Level.setTile(x-2,y,z,201,8);
Level.setTile(x-3,y,z,201,9);
Level.setTile(x-5,y,z,207,0);
Level.setTile(x-4,y,z,210,9);
}
}} 
else if(blockData==1) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay >y-5 ; ay--) {
if(Level.getTile(x,ay-1,z)>0) {
if(Level.getTile(x,ay-2,z)>0) {
if(Level.getTile(x,ay-3,z)>0) {
if(Level.getTile(x,ay-4,z)>0) {
if(Level.getTile(x,ay-5,z)>0) {
if(Level.getTile(x,ay-6,z)>0) {
if(Level.getTile(x,ay-7,z)>0) {
if(Level.getTile(x,ay-8,z)>0) {
if(Level.getTile(x,ay-9,z)>0) {
if(Level.getTile(x,ay-10,z)>0) {
if(Level.getTile(x,ay-11,z)>0) {
if(Level.getTile(x,ay-12,z)>0) {
if(Level.getTile(x,ay-13,z)>0) {
break;
}
Level.setTile(x,ay-13,z,Level.getTile(x,ay-12,z),Level.getData(x,ay-13,z));
}Level.setTile(x,ay-12,z,Level.getTile(x,ay-11,z),Level.getData(x,ay-11,z));
}Level.setTile(x,ay-11,z,Level.getTile(x,ay-10,z),Level.getData(x,ay-10,z));
}Level.setTile(x,ay-10,z,Level.getTile(x,ay-9,z),Level.getData(x,ay-9,z));
}Level.setTile(x,ay-9,z,Level.getTile(x,ay-8,z),Level.getData(x,ay-8,z));
}Level.setTile(x,ay-8,z,Level.getTile(x,ay-7,z),Level.getData(x,ay-7,z));
}Level.setTile(x,ay-7,z,Level.getTile(x,ay-6,z),Level.getData(x,ay-6,z));
}Level.setTile(x,ay-6,z,Level.getTile(x,ay-5,z),Level.getData(x,ay-5,z));
}Level.setTile(x,ay-5,z,Level.getTile(x,ay-4,z),Level.getData(x,ay-4,z));
}Level.setTile(x,ay-4,z,Level.getTile(x,ay-3,z),Level.getData(x,ay-3,z));
}Level.setTile(x,ay-3,z,Level.getTile(x,ay-2,z),Level.getData(x,ay-2,z));
}Level.setTile(x,ay-2,z,Level.getTile(x,ay-1,z),Level.getData(x,ay-1,z));
}Level.setTile(x,ay-1,z,0); }
if(Level.getTile(x,y-1,z)==0) {
if(blockId==221){
Level.setTile(x,y,z,223,4);
Level.setTile(x,y-2,z,210,6);
Level.setTile(x,y-3,z,210,7);
Level.setTile(x,y-5,z,209,4);
Level.setTile(x,y-1,z,214,11);
Level.setTile(x,y-4,z,210,13);}
else if(blockId==222){
Level.setTile(x,y,z,224,4);
Level.setTile(x,y-2,z,210,6);
Level.setTile(x,y-3,z,210,7);
Level.setTile(x,y-5,z,203,4);
Level.setTile(x,y-1,z,214,11);
Level.setTile(x,y-4,z,210,13);
}
}  }
else if(blockData==2) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay <y+5 ; ay++) {
if(Level.getTile(x,ay+1,z)>0) {
if(Level.getTile(x,ay+2,z)>0) {
if(Level.getTile(x,ay+3,z)>0) {
if(Level.getTile(x,ay+4,z)>0) {
if(Level.getTile(x,ay+5,z)>0) {
if(Level.getTile(x,ay+6,z)>0) {
if(Level.getTile(x,ay+7,z)>0) {
if(Level.getTile(x,ay+8,z)>0) {
if(Level.getTile(x,ay+9,z)>0) {
if(Level.getTile(x,ay+10,z)>0) {
if(Level.getTile(x,ay+11,z)>0) {
if(Level.getTile(x,ay+12,z)>0) {
if(Level.getTile(x,ay+13,z)>0) {
break;
}
Level.setTile(x,ay+13,z,Level.getTile(x,ay+12,z),Level.getData(x,ay+13,z));
}Level.setTile(x,ay+12,z,Level.getTile(x,ay+11,z),Level.getData(x,ay+11,z));
}Level.setTile(x,ay+11,z,Level.getTile(x,ay+10,z),Level.getData(x,ay+10,z));
}Level.setTile(x,ay+10,z,Level.getTile(x,ay+9,z),Level.getData(x,ay+9,z));
}Level.setTile(x,ay+9,z,Level.getTile(x,ay+8,z),Level.getData(x,ay+8,z));
}Level.setTile(x,ay+8,z,Level.getTile(x,ay+7,z),Level.getData(x,ay+7,z));
}Level.setTile(x,ay+7,z,Level.getTile(x,ay+6,z),Level.getData(x,ay+6,z));
}Level.setTile(x,ay+6,z,Level.getTile(x,ay+5,z),Level.getData(x,ay+5,z));
}Level.setTile(x,ay+5,z,Level.getTile(x,ay+4,z),Level.getData(x,ay+4,z));
}Level.setTile(x,ay+4,z,Level.getTile(x,ay+3,z),Level.getData(x,ay+3,z));
}Level.setTile(x,ay+3,z,Level.getTile(x,ay+2,z),Level.getData(x,ay+2,z));
}Level.setTile(x,ay+2,z,Level.getTile(x,ay+1,z),Level.getData(x,ay+1,z));
}Level.setTile(x,ay+1,z,0); }
if(Level.getTile(x,y+1,z)==0) {
if(blockId==221) {
Level.setTile(x,y,z,223,3);
Level.setTile(x,y+2,z,201,14);
Level.setTile(x,y+3,z,201,15);
Level.setTile(x,y+5,z,209,3);
Level.setTile(x,y+1,z,214,10);
Level.setTile(x,y+4,z,210,12);}
if(blockId==222) {
Level.setTile(x,y,z,224,3);
Level.setTile(x,y+2,z,201,14);
Level.setTile(x,y+3,z,201,15);
Level.setTile(x,y+5,z,203,3);
Level.setTile(x,y+1,z,214,10);
Level.setTile(x,y+4,z,210,12);
}}
} 
else if(blockData==4) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az >z-5 ; az--) {
if(Level.getTile(x,y,az-1)>0) {
if(Level.getTile(x,y,az-2)>0) {
if(Level.getTile(x,y,az-3)>0) {
if(Level.getTile(x,y,az-4)>0) {
if(Level.getTile(x,y,az-5)>0) {
if(Level.getTile(x,y,az-6)>0) {
if(Level.getTile(x,y,az-7)>0) {
if(Level.getTile(x,y,az-8)>0) {
if(Level.getTile(x,y,az-9)>0) {
if(Level.getTile(x,y,az-10)>0) {
if(Level.getTile(x,y,az-11)>0) {
if(Level.getTile(x,y,az-12)>0) {
if(Level.getTile(x,y,az-13)>0) {
break;
}
Level.setTile(x,y,az-13,Level.getTile(x,y,az-12),Level.getData(x,y,az-12));
}Level.setTile(x,y,az-12,Level.getTile(x,y,az-11),Level.getData(x,y,az-11));
}Level.setTile(x,y,az-11,Level.getTile(x,y,az-10),Level.getData(x,y,az-10));
}Level.setTile(x,y,az-10,Level.getTile(x,y,az-9),Level.getData(x,y,az-9));
}Level.setTile(x,y,az-9,Level.getTile(x,y,az-8),Level.getData(x,y,az-8));
}Level.setTile(x,y,az-8,Level.getTile(x,y,az-7),Level.getData(x,y,az-7));
}Level.setTile(x,y,az-7,Level.getTile(x,y,az-6),Level.getData(x,y,az-6));
}Level.setTile(x,y,az-6,Level.getTile(x,y,az-5),Level.getData(x,y,az-5));
}Level.setTile(x,y,az-5,Level.getTile(x,y,az-4),Level.getData(x,y,az-4));
}Level.setTile(x,y,az-4,Level.getTile(x,y,az-3),Level.getData(x,y,az-3));
}Level.setTile(x,y,az-3,Level.getTile(x,y,az-2),Level.getData(x,y,az-2));
}Level.setTile(x,y,az-2,Level.getTile(x,y,az-1),Level.getData(x,y,az-1));
}Level.setTile(x,y,az-1,0); }
if(Level.getTile(x,y,z-1)==0) {
if(blockId==221) {
Level.setTile(x,y,z,223,1);
Level.setTile(x,y,z-1,214,9);
Level.setTile(x,y,z-2,201,12);
Level.setTile(x,y,z-3,201,13);
Level.setTile(x,y,z-5,209,2);
Level.setTile(x,y,z-4,210,11);}
if(blockId==222){
Level.setTile(x,y,z,224,1);
Level.setTile(x,y,z-1,214,9);
Level.setTile(x,y,z-2,201,12);
Level.setTile(x,y,z-3,201,13);
Level.setTile(x,y,z-5,203,2);
Level.setTile(x,y,z-4,210,11);
}}
} 
else if(blockData==5) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az <z+5 ; az++) {
if(Level.getTile(x,y,az+1)>0) {
if(Level.getTile(x,y,az+2)>0) {
if(Level.getTile(x,y,az+3)>0) {
if(Level.getTile(x,y,az+4)>0) {
if(Level.getTile(x,y,az+5)>0) {
if(Level.getTile(x,y,az+6)>0) {
if(Level.getTile(x,y,az+7)>0) {
if(Level.getTile(x,y,az+8)>0) {
if(Level.getTile(x,y,az+9)>0) {
if(Level.getTile(x,y,az+10)>0) {
if(Level.getTile(x,y,az+11)>0) {
if(Level.getTile(x,y,az+12)>0) {
if(Level.getTile(x,y,az+13)>0) {
break;
}
Level.setTile(x,y,az+13,Level.getTile(x,y,az+12),Level.getData(x,y,az+12));
}Level.setTile(x,y,az+12,Level.getTile(x,y,az+11),Level.getData(x,y,az+11));
}Level.setTile(x,y,az+11,Level.getTile(x,y,az+10),Level.getData(x,y,az+10));
}Level.setTile(x,y,az+10,Level.getTile(x,y,az+9),Level.getData(x,y,az+9));
}Level.setTile(x,y,az+9,Level.getTile(x,y,az+8),Level.getData(x,y,az+8));
}Level.setTile(x,y,az+8,Level.getTile(x,y,az+7),Level.getData(x,y,az+7));
}Level.setTile(x,y,az+7,Level.getTile(x,y,az+6),Level.getData(x,y,az+6));
}Level.setTile(x,y,az+6,Level.getTile(x,y,az+5),Level.getData(x,y,az+5));
}Level.setTile(x,y,az+5,Level.getTile(x,y,az+4),Level.getData(x,y,az+4));
}Level.setTile(x,y,az+4,Level.getTile(x,y,az+3),Level.getData(x,y,az+3));
}Level.setTile(x,y,az+3,Level.getTile(x,y,az+2),Level.getData(x,y,az+2));
}Level.setTile(x,y,az+2,Level.getTile(x,y,az+1),Level.getData(x,y,az+1));
}Level.setTile(x,y,az+1,0); }
if(Level.getTile(x,y,z+1)==0) {
if(blockId==221) {
Level.setTile(x,y,z,223,2);
Level.setTile(x,y,z+1,214,8);
Level.setTile(x,y,z+2,201,10);
Level.setTile(x,y,z+3,201,11);
Level.setTile(x,y,z+5,209,1);
Level.setTile(x,y,z+4,210,10);}
if(blockId==222) {
Level.setTile(x,y,z,224,2);
Level.setTile(x,y,z+1,214,8);
Level.setTile(x,y,z+2,201,10);
Level.setTile(x,y,z+3,201,11);
Level.setTile(x,y,z+5,203,1);
Level.setTile(x,y,z+4,210,10);
}
}
}
}
else if(blockId==226) {
if ( blockData==3) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ax=x;
for (ax ; ax <x+2 ; ax++) {
if(Level.getTile(ax+1,y,z)>0) {
if(Level.getTile(ax+2,y,z)>0) {
if(Level.getTile(ax+3,y,z)>0) {
if(Level.getTile(ax+4,y,z)>0) {
if(Level.getTile(ax+5,y,z)>0) {
if(Level.getTile(ax+6,y,z)>0) {
if(Level.getTile(ax+7,y,z)>0) {
if(Level.getTile(ax+8,y,z)>0) {
if(Level.getTile(ax+9,y,z)>0) {
if(Level.getTile(ax+10,y,z)>0) {
if(Level.getTile(ax+11,y,z)>0) {
if(Level.getTile(ax+12,y,z)>0) {
if(Level.getTile(ax+13,y,z)>0) {
break;
}
Level.setTile(ax+13,y,z,Level.getTile(ax+12,y,z),Level.getData(ax+12,y,z));
}Level.setTile(ax+12,y,z,Level.getTile(ax+11,y,z),Level.getData(ax+11,y,z));
}Level.setTile(ax+11,y,z,Level.getTile(ax+10,y,z),Level.getData(ax+10,y,z));
}Level.setTile(ax+10,y,z,Level.getTile(ax+9,y,z),Level.getData(ax+9,y,z));
}Level.setTile(ax+9,y,z,Level.getTile(ax+8,y,z),Level.getData(ax+8,y,z));
}Level.setTile(ax+8,y,z,Level.getTile(ax+7,y,z),Level.getData(ax+7,y,z));
}Level.setTile(ax+7,y,z,Level.getTile(ax+6,y,z),Level.getData(ax+6,y,z));
}Level.setTile(ax+6,y,z,Level.getTile(ax+5,y,z),Level.getData(ax+5,y,z));
}Level.setTile(ax+5,y,z,Level.getTile(ax+4,y,z),Level.getData(ax+4,y,z));
}Level.setTile(ax+4,y,z,Level.getTile(ax+3,y,z),Level.getData(ax+3,y,z));
}Level.setTile(ax+3,y,z,Level.getTile(ax+2,y,z),Level.getData(ax+2,y,z));
}Level.setTile(ax+2,y,z,Level.getTile(ax+1,y,z),Level.getData(ax+1,y,z));
}Level.setTile(ax+1,y,z,0); }
if(Level.getTile(x+1,y,z)==0) {
if(blockId==226){
Level.setTile(x,y,z,227,5);
Level.setTile(x+1,y,z,201,0);
Level.setTile(x+2,y,z,225,0);
} 
}}
 else if( blockData==0) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
 ax=x;
for (ax ; ax >x-2 ; ax--) {
if(Level.getTile(ax-1,y,z)>0) {
if(Level.getTile(ax-2,y,z)>0) {
if(Level.getTile(ax-3,y,z)>0) {
if(Level.getTile(ax-4,y,z)>0) {
if(Level.getTile(ax-5,y,z)>0) {
if(Level.getTile(ax-6,y,z)>0) {
if(Level.getTile(ax-7,y,z)>0) {
if(Level.getTile(ax-8,y,z)>0) {
if(Level.getTile(ax-9,y,z)>0) {
if(Level.getTile(ax-10,y,z)>0) {
if(Level.getTile(ax-11,y,z)>0) {
if(Level.getTile(ax-12,y,z)>0) {
if(Level.getTile(ax-13,y,z)>0) {
break;
}
Level.setTile(ax-13,y,z,Level.getTile(ax-12,y,z),Level.getData(ax-12,y,z));
}Level.setTile(ax-12,y,z,Level.getTile(ax-11,y,z),Level.getData(ax-11,y,z));
}Level.setTile(ax-11,y,z,Level.getTile(ax-10,y,z),Level.getData(ax-10,y,z));
}Level.setTile(ax-10,y,z,Level.getTile(ax-9,y,z),Level.getData(ax-9,y,z));
}Level.setTile(ax-9,y,z,Level.getTile(ax-8,y,z),Level.getData(ax-8,y,z));
}Level.setTile(ax-8,y,z,Level.getTile(ax-7,y,z),Level.getData(ax-7,y,z));
}Level.setTile(ax-7,y,z,Level.getTile(ax-6,y,z),Level.getData(ax-6,y,z));
}Level.setTile(ax-6,y,z,Level.getTile(ax-5,y,z),Level.getData(ax-5,y,z));
}Level.setTile(ax-5,y,z,Level.getTile(ax-4,y,z),Level.getData(ax-4,y,z));
}Level.setTile(ax-4,y,z,Level.getTile(ax-3,y,z),Level.getData(ax-3,y,z));
}Level.setTile(ax-3,y,z,Level.getTile(ax-2,y,z),Level.getData(ax-2,y,z));
}Level.setTile(ax-2,y,z,Level.getTile(ax-1,y,z),Level.getData(ax-1,y,z));
}Level.setTile(ax-1,y,z,0); }
if(Level.getTile(x-1,y,z)==0) {
if(blockId==226){
Level.setTile(x,y,z,227,0);
Level.setTile(x-1,y,z,201,1);
Level.setTile(x-2,y,z,225,5);

}} }
else if(blockData==1) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay >y-2 ; ay--) {
if(Level.getTile(x,ay-1,z)>0) {
if(Level.getTile(x,ay-2,z)>0) {
if(Level.getTile(x,ay-3,z)>0) {
if(Level.getTile(x,ay-4,z)>0) {
if(Level.getTile(x,ay-5,z)>0) {
if(Level.getTile(x,ay-6,z)>0) {
if(Level.getTile(x,ay-7,z)>0) {
if(Level.getTile(x,ay-8,z)>0) {
if(Level.getTile(x,ay-9,z)>0) {
if(Level.getTile(x,ay-10,z)>0) {
if(Level.getTile(x,ay-11,z)>0) {
if(Level.getTile(x,ay-12,z)>0) {
if(Level.getTile(x,ay-13,z)>0) {
break;
}
Level.setTile(x,ay-13,z,Level.getTile(x,ay-12,z),Level.getData(x,ay-13,z));
}Level.setTile(x,ay-12,z,Level.getTile(x,ay-11,z),Level.getData(x,ay-11,z));
}Level.setTile(x,ay-11,z,Level.getTile(x,ay-10,z),Level.getData(x,ay-10,z));
}Level.setTile(x,ay-10,z,Level.getTile(x,ay-9,z),Level.getData(x,ay-9,z));
}Level.setTile(x,ay-9,z,Level.getTile(x,ay-8,z),Level.getData(x,ay-8,z));
}Level.setTile(x,ay-8,z,Level.getTile(x,ay-7,z),Level.getData(x,ay-7,z));
}Level.setTile(x,ay-7,z,Level.getTile(x,ay-6,z),Level.getData(x,ay-6,z));
}Level.setTile(x,ay-6,z,Level.getTile(x,ay-5,z),Level.getData(x,ay-5,z));
}Level.setTile(x,ay-5,z,Level.getTile(x,ay-4,z),Level.getData(x,ay-4,z));
}Level.setTile(x,ay-4,z,Level.getTile(x,ay-3,z),Level.getData(x,ay-3,z));
}Level.setTile(x,ay-3,z,Level.getTile(x,ay-2,z),Level.getData(x,ay-2,z));
}Level.setTile(x,ay-2,z,Level.getTile(x,ay-1,z),Level.getData(x,ay-1,z));
}Level.setTile(x,ay-1,z,0); }
if(Level.getTile(x,y-1,z)==0) {
if(blockId==226){
Level.setTile(x,y,z,227,4);
Level.setTile(x,y-1,z,210,5);
Level.setTile(x,y-2,z,225,4);}

}  }
else if(blockData==2) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
ay=y;
for (ay ; ay <y+2 ; ay++) {
if(Level.getTile(x,ay+1,z)>0) {
if(Level.getTile(x,ay+2,z)>0) {
if(Level.getTile(x,ay+3,z)>0) {
if(Level.getTile(x,ay+4,z)>0) {
if(Level.getTile(x,ay+5,z)>0) {
if(Level.getTile(x,ay+6,z)>0) {
if(Level.getTile(x,ay+7,z)>0) {
if(Level.getTile(x,ay+8,z)>0) {
if(Level.getTile(x,ay+9,z)>0) {
if(Level.getTile(x,ay+10,z)>0) {
if(Level.getTile(x,ay+11,z)>0) {
if(Level.getTile(x,ay+12,z)>0) {
if(Level.getTile(x,ay+13,z)>0) {
break;
}
Level.setTile(x,ay+13,z,Level.getTile(x,ay+12,z),Level.getData(x,ay+13,z));
}Level.setTile(x,ay+12,z,Level.getTile(x,ay+11,z),Level.getData(x,ay+11,z));
}Level.setTile(x,ay+11,z,Level.getTile(x,ay+10,z),Level.getData(x,ay+10,z));
}Level.setTile(x,ay+10,z,Level.getTile(x,ay+9,z),Level.getData(x,ay+9,z));
}Level.setTile(x,ay+9,z,Level.getTile(x,ay+8,z),Level.getData(x,ay+8,z));
}Level.setTile(x,ay+8,z,Level.getTile(x,ay+7,z),Level.getData(x,ay+7,z));
}Level.setTile(x,ay+7,z,Level.getTile(x,ay+6,z),Level.getData(x,ay+6,z));
}Level.setTile(x,ay+6,z,Level.getTile(x,ay+5,z),Level.getData(x,ay+5,z));
}Level.setTile(x,ay+5,z,Level.getTile(x,ay+4,z),Level.getData(x,ay+4,z));
}Level.setTile(x,ay+4,z,Level.getTile(x,ay+3,z),Level.getData(x,ay+3,z));
}Level.setTile(x,ay+3,z,Level.getTile(x,ay+2,z),Level.getData(x,ay+2,z));
}Level.setTile(x,ay+2,z,Level.getTile(x,ay+1,z),Level.getData(x,ay+1,z));
}Level.setTile(x,ay+1,z,0); }
if(Level.getTile(x,y+1,z)==0) {
if(blockId==226) {
Level.setTile(x,y,z,227,3);
Level.setTile(x,y+1,z,201,4);
Level.setTile(x,y+2,z,225,3);}
}
} 
else if(blockData==4) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az >z-2 ; az--) {
if(Level.getTile(x,y,az-1)>0) {
if(Level.getTile(x,y,az-2)>0) {
if(Level.getTile(x,y,az-3)>0) {
if(Level.getTile(x,y,az-4)>0) {
if(Level.getTile(x,y,az-5)>0) {
if(Level.getTile(x,y,az-6)>0) {
if(Level.getTile(x,y,az-7)>0) {
if(Level.getTile(x,y,az-8)>0) {
if(Level.getTile(x,y,az-9)>0) {
if(Level.getTile(x,y,az-10)>0) {
if(Level.getTile(x,y,az-11)>0) {
if(Level.getTile(x,y,az-12)>0) {
if(Level.getTile(x,y,az-13)>0) {
break;
}
Level.setTile(x,y,az-13,Level.getTile(x,y,az-12),Level.getData(x,y,az-12));
}Level.setTile(x,y,az-12,Level.getTile(x,y,az-11),Level.getData(x,y,az-11));
}Level.setTile(x,y,az-11,Level.getTile(x,y,az-10),Level.getData(x,y,az-10));
}Level.setTile(x,y,az-10,Level.getTile(x,y,az-9),Level.getData(x,y,az-9));
}Level.setTile(x,y,az-9,Level.getTile(x,y,az-8),Level.getData(x,y,az-8));
}Level.setTile(x,y,az-8,Level.getTile(x,y,az-7),Level.getData(x,y,az-7));
}Level.setTile(x,y,az-7,Level.getTile(x,y,az-6),Level.getData(x,y,az-6));
}Level.setTile(x,y,az-6,Level.getTile(x,y,az-5),Level.getData(x,y,az-5));
}Level.setTile(x,y,az-5,Level.getTile(x,y,az-4),Level.getData(x,y,az-4));
}Level.setTile(x,y,az-4,Level.getTile(x,y,az-3),Level.getData(x,y,az-3));
}Level.setTile(x,y,az-3,Level.getTile(x,y,az-2),Level.getData(x,y,az-2));
}Level.setTile(x,y,az-2,Level.getTile(x,y,az-1),Level.getData(x,y,az-1));
}Level.setTile(x,y,az-1,0); }
if(Level.getTile(x,y,z-1)==0) {
if(blockId==226) {
Level.setTile(x,y,z,227,1);
Level.setTile(x,y,z-1,201,2);
Level.setTile(x,y,z-2,225,2);}
}
} 
else if(blockData==5) {
Level.playSound(x,y,z,"tile.piston.out",25,1);
az=z;
for (az ; az <z+2 ; az++) {
if(Level.getTile(x,y,az+1)>0) {
if(Level.getTile(x,y,az+2)>0) {
if(Level.getTile(x,y,az+3)>0) {
if(Level.getTile(x,y,az+4)>0) {
if(Level.getTile(x,y,az+5)>0) {
if(Level.getTile(x,y,az+6)>0) {
if(Level.getTile(x,y,az+7)>0) {
if(Level.getTile(x,y,az+8)>0) {
if(Level.getTile(x,y,az+9)>0) {
if(Level.getTile(x,y,az+10)>0) {
if(Level.getTile(x,y,az+11)>0) {
if(Level.getTile(x,y,az+12)>0) {
if(Level.getTile(x,y,az+13)>0) {
break;
}
Level.setTile(x,y,az+13,Level.getTile(x,y,az+12),Level.getData(x,y,az+12));
}Level.setTile(x,y,az+12,Level.getTile(x,y,az+11),Level.getData(x,y,az+11));
}Level.setTile(x,y,az+11,Level.getTile(x,y,az+10),Level.getData(x,y,az+10));
}Level.setTile(x,y,az+10,Level.getTile(x,y,az+9),Level.getData(x,y,az+9));
}Level.setTile(x,y,az+9,Level.getTile(x,y,az+8),Level.getData(x,y,az+8));
}Level.setTile(x,y,az+8,Level.getTile(x,y,az+7),Level.getData(x,y,az+7));
}Level.setTile(x,y,az+7,Level.getTile(x,y,az+6),Level.getData(x,y,az+6));
}Level.setTile(x,y,az+6,Level.getTile(x,y,az+5),Level.getData(x,y,az+5));
}Level.setTile(x,y,az+5,Level.getTile(x,y,az+4),Level.getData(x,y,az+4));
}Level.setTile(x,y,az+4,Level.getTile(x,y,az+3),Level.getData(x,y,az+3));
}Level.setTile(x,y,az+3,Level.getTile(x,y,az+2),Level.getData(x,y,az+2));
}Level.setTile(x,y,az+2,Level.getTile(x,y,az+1),Level.getData(x,y,az+1));
}Level.setTile(x,y,az+1,0); }
if(Level.getTile(x,y,z+1)==0) {
if(blockId==226) {
Level.setTile(x,y,z,227,2);
Level.setTile(x,y,z+1,201,3);
Level.setTile(x,y,z+2,225,1);}

}
}
}
}
else if(newCurrent==0) {
if(blockId==202 && blockData==0) {
Level.setTile(x,y,z,204);
Level.setTile(x+1,y,z,Level.getTile(x+3,y,z),Level.getData(x+3,y,z));
Level.setTile(x+3,y,z,0);
Level.setTile(x+2,y,z,0);
Level.playSound(x,y+1,z,"tile.piston.in",25,1);}
 else if(blockId==208 && blockData==0) {
 Level.setTile(x,y,z,205);
Level.setTile(x-1,y,z,Level.getTile(x-3,y,z),Level.getData(x-3,y,z));
Level.setTile(x-3,y,z,0);
Level.setTile(x-2,y,z,0);



Level.playSound(x,y-1,z,"tile.piston.in",25,1);
} else if(blockId==208 && blockData==1) {
Level.setTile(x,y,z,204,1);
Level.setTile(x,y,z-1,Level.getTile(x,y,z-3),Level.getData(x,y,z-3));
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3,0);
Level.playSound(x,y,z,"tile.piston.in",25,1);
} else if(blockId==208 && blockData==2) {
Level.setTile(x,y,z,204,2);
Level.setTile(x,y,z+1,Level.getTile(x,y,z+3),Level.getData(x,y,z+3));
Level.setTile(x,y,z+2,0);


Level.setTile(x,y,z+3,0);
Level.playSound(x,y,z,"tile.piston.in",25,1);
}
else if(blockId==208 && blockData==4) {
Level.setTile(x,y,z,205,1);
Level.setTile(x,y-1,z,Level.getTile(x,y-3,z),Level.getData(x,y-3,z));
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-3,z,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
 }
 else if(blockId==208 && blockData==3) {
Level.setTile(x,y,z,205,2);
Level.setTile(x,y+1,z,Level.getTile(x,y+3,z),Level.getData(x,y+3,z));
Level.setTile(x,y+2,z,0);
Level.setTile(x,y+3,z,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
 }
else if( blockId==211 && blockData==0) {
Level.setTile(x,y,z,206,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-1,y,z,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
}
else if(blockId==211 && blockData==5){
Level.setTile(x,y,z,206,3);
Level.setTile(x+2,y,z,0);
Level.setTile(x+1,y,z,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
}
 else if(blockId==211 && blockData==4){
Level.setTile(x,y,z,206,1);
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
}
 else if(blockId==211 && blockData==3){
Level.setTile(x,y,z,206,2);
Level.setTile(x,y+2,z,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
 Level.setTile(x,y+1,z,0);
}
 else if(blockId==211 && blockData==1){
Level.setTile(x,y,z,206,4);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-1,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
 }
 else if(blockId==211 && blockData==2){
Level.setTile(x,y,z,206,5);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+1,0);

Level.playSound(x,y,z,"tile.piston.in",25,1);
 }
 else if(blockId==213 || blockId==215) {
 Level.playSound(x,y,z,"tile.piston.in",25,1);
if(data==5){
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
Level.setTile(x+3,y,z,0);
if(blockId==213) {
Level.setTile(x,y,z,212,3)}
if(blockId==215) {
Level.setTile(x,y,z,216,3);
Level.setTile(x+1,y,z,Level.getTile(x+4,y,z),Level.getData(x+4,y,z));
Level.setTile(x+4,y,z,0);
}}
if( data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-3,y,z,0);
if(blockId==213) {
Level.setTile(x,y,z,212,0)}
if(blockId==215) {
Level.setTile(x,y,z,216,0);
Level.setTile(x-1,y,z,Level.getTile(x-4,y,z),Level.getData(x-4,y,z));
Level.setTile(x-4,y,z,0);
}}
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3,0);
if(blockId==213) {
Level.setTile(x,y,z,212,4)}
if(blockId==215) {
Level.setTile(x,y,z,216,4);
Level.setTile(x,y,z-1,Level.getTile(x,y,z-4),Level.getData(x,y,z-4));
Level.setTile(x,y,z-4,0);
 }
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+3,0);
 if(blockId==213) {
Level.setTile(x,y,z,212,5)}
if(blockId==215) {
Level.setTile(x,y,z,216,5);
Level.setTile(x,y,z+1,Level.getTile(x,y,z+4),Level.getData(x,y,z+4));
Level.setTile(x,y,z+4,0);
}}
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+3,z,0);
Level.setTile(x,y+2,z,0);
if(blockId==213) {
Level.setTile(x,y,z,212,2)}
if(blockId==215) {
Level.setTile(x,y,z,216,2);
Level.setTile(x,y+1,z,Level.getTile(x,y+4,z),Level.getData(x,y+4,z));
Level.setTile(x,y+4,z,0);
}}
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-3,z,0);
if(blockId==213) {
Level.setTile(x,y,z,212,1)}
if(blockId==215) {
Level.setTile(x,y,z,216,1);
Level.setTile(x,y-1,z,Level.getTile(x,y-4,z),Level.getData(x,y-4,z));
Level.setTile(x,y-4,z,0);
 }
}
}
else if(blockId==219 || blockId==220) {
 Level.playSound(x,y,z,"tile.piston.in",25,1);
if(data==5){
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
Level.setTile(x+3,y,z,0);
Level.setTile(x+4,y,z,0);
if(blockId==219) {
Level.setTile(x,y,z,217,3)}
if(blockId==220) {
Level.setTile(x,y,z,218,3);
Level.setTile(x+1,y,z,Level.getTile(x+5,y,z),Level.getData(x+5,y,z));
Level.setTile(x+5,y,z,0);
}}
if( data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-3,y,z,0);
Level.setTile(x-4,y,z,0);
if(blockId==219) {
Level.setTile(x,y,z,217,0)}
if(blockId==220) {
Level.setTile(x,y,z,218,0);
Level.setTile(x-1,y,z,Level.getTile(x-5,y,z),Level.getData(x-5,y,z));
Level.setTile(x-5,y,z,0);
}}
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3,0);
Level.setTile(x,y,z-4,0);
if(blockId==219) {
Level.setTile(x,y,z,217,4)}
if(blockId==220) {
Level.setTile(x,y,z,218,4);
Level.setTile(x,y,z-1,Level.getTile(x,y,z-5),Level.getData(x,y,z-5));
Level.setTile(x,y,z-5,0);
 }
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+3,0);
Level.setTile(x,y,z+4,0);
 if(blockId==219) {
Level.setTile(x,y,z,217,5)}
if(blockId==220) {
Level.setTile(x,y,z,218,5);
Level.setTile(x,y,z+1,Level.getTile(x,y,z+5),Level.getData(x,y,z+5));
Level.setTile(x,y,z+5,0);
}}
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+3,z,0);
Level.setTile(x,y+2,z,0);
Level.setTile(x,y+4,z,0);
if(blockId==219) {
Level.setTile(x,y,z,217,2)}
if(blockId==220) {
Level.setTile(x,y,z,218,2);
Level.setTile(x,y+1,z,Level.getTile(x,y+5,z),Level.getData(x,y+5,z));
Level.setTile(x,y+5,z,0);
}}
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-3,z,0);
Level.setTile(x,y-4,z,0);
if(blockId==219) {
Level.setTile(x,y,z,217,1)}
if(blockId==220) {
Level.setTile(x,y,z,218,1);
Level.setTile(x,y-1,z,Level.getTile(x,y-5,z),Level.getData(x,y-5,z));
Level.setTile(x,y-5,z,0);
 }
}
}
else if(blockId==223 || blockId==224) {
 Level.playSound(x,y,z,"tile.piston.in",25,1);
if(data==5){
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
Level.setTile(x+3,y,z,0);
Level.setTile(x+4,y,z,0);
Level.setTile(x+5,y,z,0);
if(blockId==223) {
Level.setTile(x,y,z,221,3)}
if(blockId==224) {
Level.setTile(x,y,z,222,3);
Level.setTile(x+1,y,z,Level.getTile(x+6,y,z),Level.getData(x+6,y,z));
Level.setTile(x+6,y,z,0);
}}
if( data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-3,y,z,0);
Level.setTile(x-4,y,z,0);
Level.setTile(x-5,y,z,0);
if(blockId==223) {
Level.setTile(x,y,z,221,0)}
if(blockId==224) {
Level.setTile(x,y,z,222,0);
Level.setTile(x-1,y,z,Level.getTile(x-6,y,z),Level.getData(x-6,y,z));
Level.setTile(x-6,y,z,0);
}}
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3,0);
Level.setTile(x,y,z-4,0);
Level.setTile(x,y,z-5,0);
if(blockId==223) {
Level.setTile(x,y,z,221,4)}
if(blockId==224) {
Level.setTile(x,y,z,222,4);
Level.setTile(x,y,z-1,Level.getTile(x,y,z-6),Level.getData(x,y,z-6));
Level.setTile(x,y,z-6,0);
 }
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+3,0);
Level.setTile(x,y,z+4,0);
Level.setTile(x,y,z+5,0);
 if(blockId==223) {
Level.setTile(x,y,z,221,5)}
if(blockId==224) {
Level.setTile(x,y,z,222,5);
Level.setTile(x,y,z+1,Level.getTile(x,y,z+6),Level.getData(x,y,z+6));
Level.setTile(x,y,z+6,0);
}}
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+3,z,0);
Level.setTile(x,y+2,z,0);
Level.setTile(x,y+4,z,0);
Level.setTile(x,y+5,z,0);
if(blockId==223) {
Level.setTile(x,y,z,221,2)}
if(blockId==224) {
Level.setTile(x,y,z,222,2);
Level.setTile(x,y+1,z,Level.getTile(x,y+6,z),Level.getData(x,y+6,z));
Level.setTile(x,y+6,z,0);
}}
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-3,z,0);
Level.setTile(x,y-4,z,0);
Level.setTile(x,y-5,z,0);
if(blockId==223) {
Level.setTile(x,y,z,221,1)}
if(blockId==224) {
Level.setTile(x,y,z,222,1);
Level.setTile(x,y-1,z,Level.getTile(x,y-6,z),Level.getData(x,y-6,z));
Level.setTile(x,y-6,z,0);
 }
}
}
else if(blockId==227) {
Level.playSound(x,y,z,"tile.piston.in",25,1);
if(data==5) {
Level.setTile(x,y,z,226,3);
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
if(Level.getTile(x+3,y,z)>0) {Level.setTile(x+1,y,z,Level.getTile(x+3,y,z),Level.getData(x+3,y,z));
if(Level.getTile(x+4,y,z)>0) {Level.setTile(x+2,y,z,Level.getTile(x+4,y,z),Level.getData(x+4,y,z)); Level.setTile(x+4,y,z);
} Level.setTile(x+3,y,z);
}
}
if(data==0) {
Level.setTile(x,y,z,226,0);
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
 if(Level.getTile(x-3,y,z)>0) {Level.setTile(x-1,y,z,Level.getTile(x-3,y,z),Level.getData(x-3,y,z));
if(Level.getTile(x-4,y,z)>0) {Level.setTile(x-2,y,z,Level.getTile(x-4,y,z),Level.getData(x-4,y,z)); Level.setTile(x-4,y,z);
} Level.setTile(x-3,y,z);
}
}
if(data==1) {
Level.setTile(x,y,z,226,4);
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
if(Level.getTile(x,y,z-3)>0) {Level.setTile(x,y,z-1,Level.getTile(x,y,z-3),Level.getData(x,y,z-3));
if(Level.getTile(x,y,z-4)>0) {Level.setTile(x,y,z-2,Level.getTile(x,y,z-4),Level.getData(x,y,z-4)); Level.setTile(x,y,z-4);
} Level.setTile(x,y,z-3);
}
}
if(data==2) {
Level.setTile(x,y,z,226,5);
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
if(Level.getTile(x,y,z+3)>0) {Level.setTile(x,y,z+1,Level.getTile(x,y,z+3),Level.getData(x,y,z+3));
if(Level.getTile(x,y,z+4)>0) {Level.setTile(x,y,z+2,Level.getTile(x,y,z+4),Level.getData(x,y,z+4)); Level.setTile(x,y,z+4);
} Level.setTile(x,y,z+3);
}
}
if(data==4) {
Level.setTile(x,y,z,226,1);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-2,z,0);
if(Level.getTile(x,y-3,z)>0) {Level.setTile(x,y-1,z,Level.getTile(x,y-3,z),Level.getData(x,y-3,z));
if(Level.getTile(x,y-4,z)>0) {Level.setTile(x,y-2,z,Level.getTile(x,y-4,z),Level.getData(x,y-4,z)); Level.setTile(x,y-4,z);
} Level.setTile(x,y-3,z);
}
}
if(data==3) {
Level.setTile(x,y,z,226,2);
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
if(Level.getTile(x,y+3,z)>0) {Level.setTile(x,y+1,z,Level.getTile(x,y+3,z),Level.getData(x,y+3,z));
if(Level.getTile(x,y+4,z)>0) {Level.setTile(x,y+2,z,Level.getTile(x,y+4,z),Level.getData(x,y+4,z)); Level.setTile(x,y+4,z);
} Level.setTile(x,y+3,z);
}
}

}
}
}

function destroyBlock(x,y,z,shouldDropItem){
var blockId = Level.getTile(x,y,z);
	var data = Level.getData(x,y,z);
if(Level.getGameMode()==0) {
	if(blockId==204||blockId==205||blockId==202||blockId==208) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,205,1,2);
	}
	if(blockId==211||blockId==206 ) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,206,1,2);
	}
	if(blockId==212||blockId==213) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,212,1,2);
	}
	if(blockId==216||blockId==215) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,216,1,2);
	}
	if(blockId==217||blockId==219) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,217,1,2);
	}
	if(blockId==218||blockId==220) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,218,1,2);
	}
	if(blockId==221||blockId==223) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,221,1,2);
	}
	if(blockId==222||blockId==224) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,222,1,2);
	}
	if(blockId==226||blockId==227) {
	preventDefault;
	Level.destroyBlock(x,y,z,false);
	Level.dropItem(x,y,z,0.5,226,1,2);
	}}
if(blockId==211) {
if(data==4) {
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-2,z,0);
}
else if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
}
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
}
 if(data==0) {
Level.setTile(x-2,y,z,0);
Level.setTile(x-1,y,z,0);
}
 if(data==5) {
Level.setTile(x+2,y,z,0);
Level.setTile(x+1,y,z,0);
}}
else if(blockId==202 || blockId==208 ) {
if(blockId==202) {
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
}
else if(blockId==208 && data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
}
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
}
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
}
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
}
} 
if(blockId==213 || blockId==215) {
if(data==5){
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
Level.setTile(x+3,y,z);
}
if( data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-3,y,z);
 }
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3);
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+3);
 }
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
Level.setTile(x,y+3,z);
 }
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-3,z);

}
}if(blockId==219 || blockId==220) {
if(data==5){
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
Level.setTile(x+3,y,z);
Level.setTile(x+4,y,z);
}
if( data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-3,y,z);
Level.setTile(x-4,y,z);
 }
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3);
Level.setTile(x,y,z-4);
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+3);
 Level.setTile(x,y,z+4);
 }
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
Level.setTile(x,y+3,z);
Level.setTile(x,y+4,z);
 }
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-3,z);
Level.setTile(x,y-4,z);
}}
if(blockId==223|| blockId==224) {
if(data==5){
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
Level.setTile(x+3,y,z);
Level.setTile(x+4,y,z);
Level.setTile(x+5,y,z);
}
if( data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
Level.setTile(x-3,y,z);
Level.setTile(x-4,y,z);
Level.setTile(x-5,y,z);
 }
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
Level.setTile(x,y,z-3);
Level.setTile(x,y,z-4);
Level.setTile(x,y,z-5);
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
Level.setTile(x,y,z+3);
 Level.setTile(x,y,z+4);
 Level.setTile(x,y,z+5);
 }
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
Level.setTile(x,y+3,z);
Level.setTile(x,y+4,z);
Level.setTile(x,y+5,z);
 }
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
Level.setTile(x,y-3,z);
Level.setTile(x,y-4,z);
Level.setTile(x,y-5,z);
}
}
else if(blockId==227) {
if(data==5) {
Level.setTile(x+1,y,z,0);
Level.setTile(x+2,y,z,0);
}
if(data==0) {
Level.setTile(x-1,y,z,0);
Level.setTile(x-2,y,z,0);
}
 if(data==1) {
Level.setTile(x,y,z-1,0);
Level.setTile(x,y,z-2,0);
}
 if(data==2) {
Level.setTile(x,y,z+1,0);
Level.setTile(x,y,z+2,0);
}
 if(data==3) {
Level.setTile(x,y+1,z,0);
Level.setTile(x,y+2,z,0);
}
 if(data==4) {
Level.setTile(x,y-2,z,0);
Level.setTile(x,y-1,z,0);
}
} 
 if(blockId==201 || blockId==203 || blockId==207 || blockId==209 || blockId==210 ||blockId==214 || blockId==225)
{ 
preventDefault(); }
}
Player.addItemCreativeInv(206,2,2);
Player.addItemCreativeInv(205,2,2);
Player.addItemCreativeInv(212,2,2);
Player.addItemCreativeInv(216,2,2);
Player.addItemCreativeInv(217,2,2);
Player.addItemCreativeInv(218,2,2);
Player.addItemCreativeInv(221,2,2);
Player.addItemCreativeInv(222,2,2);
Player.addItemCreativeInv(226,2,2);


Item.setCategory(221,ItemCategory.TOOL);
Item.setCategory(222,ItemCategory.TOOL);
Item.setCategory(226,ItemCategory.TOOL);

//crafting recipes
Item.addShapedRecipe(205, 1, 2, ["aba","aca","aba"], ["b", 33, 0,"c",265,0]);
Item.addShapedRecipe(206, 1, 2, ["aba","aca","aaa"], ["c", 205, 2,"b",341,0]);
Item.addShapedRecipe(212, 1, 2, ["aba","bcb","aaa"], ["b",33,0,"c",265,0]);
Item.addShapedRecipe(216, 1, 2, ["aba","aca","aaa"], ["b",341,0,"c",212,2]);
Item.addShapedRecipe(217,1,2,   ["aba","bcb","aba"], ["b",33,0,"c",265,0]);
Item.addShapedRecipe(218,1,2,   ["aba","aca","aaa"], ["b",341,0,"c",217,2]);
Item.addShapedRecipe(221,1,2,   ["bab","aba","bab"], ["b",33,0,"a",265,0]);
Item.addShapedRecipe(222,1,2,   ["aba","aca","aaa"], ["b",341,0,"c",221,2]);
Item.addShapedRecipe(226,1,2,   ["aaa","bcb","bcb"], ["a",265,0,"b",4,0,"c",33,0]);


