//this mod has been updated to work for 0.15

ModPE.setItem(600, "blaze_rod", 0, "Morphing Rod", 1);

Item.addCraftRecipe(600, 1, 0, [12,4,0]);

function newLevel()
{
clientMessage("Enter third person mode for the mod to work properly! You can find the morph rod in your creative inventory.");
Player.addItemCreativeInv(600,1,0);
}

function attackHook(attacker, victim) {
	if(Player.getCarriedItem() === 600) {
		
var render = Entity.getRenderType(victim);

var mobskin = Entity.getMobSkin(victim);

Entity.setRenderType(Player.getEntity(),render);
			Entity.setMobSkin(Player.getEntity(),mobskin);
			
			if(render === 6) {
				render =11;
				}
			
			
			}
			}
	
